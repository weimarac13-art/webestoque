import { Product, Movement } from './types';

export const INITIAL_PRODUCTS: Product[] = [];

export const INITIAL_MOVEMENTS: Movement[] = [];

export const CATEGORIES = [
  'Eletrônicos',
  'Alimentos & Bebidas',
  'Vestuário',
  'Ferramentas',
  'Papelaria',
  'Outros'
];
