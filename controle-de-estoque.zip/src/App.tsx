import React, { useState, useEffect } from 'react';
import { 
  Package, 
  AlertTriangle, 
  ArrowUpDown, 
  DollarSign, 
  Plus, 
  Trash2, 
  Edit, 
  Search, 
  Filter, 
  ChevronRight, 
  ArrowUpRight, 
  ArrowDownRight, 
  Building, 
  MapPin, 
  FileText,
  Clock,
  RefreshCw,
  TrendingUp,
  X,
  User,
  Menu,
  Shield,
  HelpCircle,
  FileCheck2,
  CalendarDays
} from 'lucide-react';

import { Product, Movement, Notification, ActiveTab, Technician } from './types';
import { INITIAL_PRODUCTS, INITIAL_MOVEMENTS, CATEGORIES } from './data';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import MetricCard from './components/MetricCard';
import ProductForm from './components/ProductForm';
import MovementForm from './components/MovementForm';
import TechnicianForm from './components/TechnicianForm';
import NotificationDrawer from './components/NotificationDrawer';
import WhatsAppModal from './components/WhatsAppModal';

export default function App() {
  // --- STATE ---
  const [products, setProducts] = useState<Product[]>(() => {
    const hasCleared = localStorage.getItem('si_estoque_cleared_v3');
    if (!hasCleared) {
      localStorage.removeItem('si_estoque_products');
      localStorage.removeItem('si_estoque_movements');
      localStorage.setItem('si_estoque_cleared_v3', 'true');
      return [];
    }
    const saved = localStorage.getItem('si_estoque_products');
    return saved ? JSON.parse(saved) : [];
  });

  const [movements, setMovements] = useState<Movement[]>(() => {
    const hasCleared = localStorage.getItem('si_estoque_cleared_v3');
    if (!hasCleared) {
      return [];
    }
    const saved = localStorage.getItem('si_estoque_movements');
    return saved ? JSON.parse(saved) : [];
  });

  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [activeTab, setActiveTab] = useState<ActiveTab>('inicio');

  const [technicians, setTechnicians] = useState<Technician[]>(() => {
    const saved = localStorage.getItem('si_estoque_technicians');
    return saved ? JSON.parse(saved) : [];
  });
  
  // UI States
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  
  const [productFormOpen, setProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  const [movementFormOpen, setMovementFormOpen] = useState(false);
  const [technicianFormOpen, setTechnicianFormOpen] = useState(false);
  const [editingTechnician, setEditingTechnician] = useState<Technician | null>(null);
  const [preselectedMovementProductId, setPreselectedMovementProductId] = useState<string | undefined>(undefined);
  const [whatsappPromptMovement, setWhatsappPromptMovement] = useState<Movement | null>(null);
  
  const [selectedProductDetails, setSelectedProductDetails] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('Todas');
  const [stockStatusFilter, setStockStatusFilter] = useState('Todos'); // Todos, Baixo, Normal, Esgotado

  // --- LOCAL PERSISTENCE ---
  useEffect(() => {
    localStorage.setItem('si_estoque_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('si_estoque_movements', JSON.stringify(movements));
  }, [movements]);

  useEffect(() => {
    localStorage.setItem('si_estoque_technicians', JSON.stringify(technicians));
  }, [technicians]);

  // --- AUTOMATIC ALERTS GENERATION ---
  useEffect(() => {
    const lowStockItems = products.filter(p => p.quantity <= p.minQuantity);
    const outOfStockItems = products.filter(p => p.quantity === 0);
    
    const generatedNotifs: Notification[] = [];

    // Low stock items
    lowStockItems.forEach(p => {
      const isOOS = p.quantity === 0;
      generatedNotifs.push({
        id: `notif-low-${p.id}`,
        type: 'ALERT',
        title: isOOS ? 'PRODUTO ESGOTADO!' : 'Estoque Baixo!',
        message: isOOS 
          ? `O item "${p.name}" está sem estoque disponível no momento.` 
          : `O item "${p.name}" atingiu ${p.quantity} unidades (mínimo: ${p.minQuantity}).`,
        date: p.createdAt || new Date().toISOString(),
        read: false
      });
    });

    // Recent movements summary (max 3)
    const recentMovs = [...movements]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 3);

    recentMovs.forEach(m => {
      generatedNotifs.push({
        id: `notif-mov-${m.id}`,
        type: 'INFO',
        title: m.type === 'ENTRADA' ? 'Entrada Registrada' : 'Saída Registrada',
        message: `${m.quantity} un de "${m.productName}" lançada por ${m.responsible}.`,
        date: m.date,
        read: true // pre-read movement history logs
      });
    });

    setNotifications(generatedNotifs);
  }, [products, movements]);

  // --- DERIVED METRICS ---
  const totalProductsCount = products.length;
  const totalPhysicalStock = products.reduce((sum, p) => sum + p.quantity, 0);
  const lowStockProductsCount = products.filter(p => p.quantity <= p.minQuantity).length;
  const totalMovementsCount = movements.length;
  const totalEntradas = movements.filter(m => m.type === 'ENTRADA').reduce((sum, m) => sum + m.quantity, 0);
  const totalSaidas = movements.filter(m => m.type === 'SAÍDA').reduce((sum, m) => sum + m.quantity, 0);

  const totalInventoryValue = products.reduce((sum, p) => sum + (p.quantity * p.salePrice), 0);
  const totalCostValue = products.reduce((sum, p) => sum + (p.quantity * p.costPrice), 0);
  const totalPotentialProfit = totalInventoryValue - totalCostValue;

  // Format currency
  const formatBRL = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  // --- HANDLERS ---
  const handleSaveProduct = (prodData: Omit<Product, 'createdAt'> & { id?: string }, keepOpen?: boolean) => {
    if (prodData.id) {
      // Edit
      setProducts(prev => prev.map(p => {
        if (p.id === prodData.id) {
          return {
            ...p,
            ...prodData,
            quantity: Number(p.quantity), // maintain quantity from stock movements
          } as Product;
        }
        return p;
      }));
    } else {
      // Add new product
      const newProduct: Product = {
        ...(prodData as Omit<Product, 'id' | 'createdAt'>),
        id: `prod-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      setProducts(prev => [newProduct, ...prev]);
    }

    if (!keepOpen) {
      setProductFormOpen(false);
      setEditingProduct(null);
    }
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Tem certeza que deseja remover este produto permanentemente? Os dados de estoque serão apagados.')) {
      setProducts(prev => prev.filter(p => p.id !== id));
      setMovements(prev => prev.filter(m => m.productId !== id));
      if (selectedProductDetails?.id === id) {
        setSelectedProductDetails(null);
      }
    }
  };

  const handleSaveMovement = (movData: Omit<Movement, 'id' | 'date'>) => {
    const newMovement: Movement = {
      ...movData,
      id: `mov-${Date.now()}`,
      date: new Date().toISOString()
    };

    // Update product quantity in state
    setProducts(prev => prev.map(p => {
      if (p.id === movData.productId) {
        const qtyDiff = movData.type === 'ENTRADA' ? movData.quantity : -movData.quantity;
        return {
          ...p,
          quantity: Math.max(0, p.quantity + qtyDiff)
        };
      }
      return p;
    }));

    setMovements(prev => [newMovement, ...prev]);
    setMovementFormOpen(false);
    setPreselectedMovementProductId(undefined);

    // Se for Saída do estoque Wyntech, pergunta se quer enviar para o técnico pelo WhatsApp
    if (movData.type === 'SAÍDA' && movData.estoque === 'Wyntech') {
      setWhatsappPromptMovement(newMovement);
    }
    
    // If details are open, refresh it
    if (selectedProductDetails && selectedProductDetails.id === movData.productId) {
      const prod = products.find(p => p.id === movData.productId);
      if (prod) {
        const qtyDiff = movData.type === 'ENTRADA' ? movData.quantity : -movData.quantity;
        setSelectedProductDetails({
          ...prod,
          quantity: Math.max(0, prod.quantity + qtyDiff)
        });
      }
    }
  };

  const handleSaveTechnician = (techData: Omit<Technician, 'id' | 'createdAt'>) => {
    if (editingTechnician) {
      setTechnicians(prev => prev.map(t => t.id === editingTechnician.id ? { ...t, ...techData } : t));
      setEditingTechnician(null);
    } else {
      const newTech: Technician = {
        ...techData,
        id: `tech-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      setTechnicians(prev => [newTech, ...prev]);
    }
    setTechnicianFormOpen(false);
  };

  const handleDeleteTechnician = (id: string) => {
    if (window.confirm('Tem certeza que deseja remover este técnico permanentemente?')) {
      setTechnicians(prev => prev.filter(t => t.id !== id));
    }
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleClearNotifications = () => {
    setNotifications([]);
  };

  const handleResetData = () => {
    if (window.confirm('Atenção: Isso irá redefinir o banco de dados local com as configurações iniciais de demonstração. Deseja prosseguir?')) {
      setProducts(INITIAL_PRODUCTS);
      setMovements(INITIAL_MOVEMENTS);
      localStorage.removeItem('si_estoque_products');
      localStorage.removeItem('si_estoque_movements');
      setIsSidebarOpen(false);
    }
  };

  // Filtered Products List
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.supplier.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = categoryFilter === 'Todas' || p.category === categoryFilter;
    
    let matchesStock = true;
    if (stockStatusFilter === 'Baixo') {
      matchesStock = p.quantity <= p.minQuantity && p.quantity > 0;
    } else if (stockStatusFilter === 'Esgotado') {
      matchesStock = p.quantity === 0;
    } else if (stockStatusFilter === 'Normal') {
      matchesStock = p.quantity > p.minQuantity;
    }

    return matchesSearch && matchesCategory && matchesStock;
  });

  // Unread alerts count for header bell badge
  const unreadNotificationsCount = notifications.filter(n => !n.read && n.type === 'ALERT').length;

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#111625] pb-24 font-sans select-none antialiased">
      {/* HEADER */}
      <Header
        onMenuClick={() => setIsSidebarOpen(true)}
        onSearchClick={() => setIsSearchOpen(true)}
        onNotificationsClick={() => setIsNotificationsOpen(true)}
        onQuickAddClick={() => {
          setEditingProduct(null);
          setProductFormOpen(true);
        }}
        onCalendarClick={() => {
          alert("Lembrete de Inventário: Próxima contagem cíclica de estoque agendada para sexta-feira às 17:00.");
        }}
        notificationCount={unreadNotificationsCount}
      />

      {/* GLOBAL SEARCH MODAL */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-20">
          <div className="absolute inset-0 bg-[#111625]/40 backdrop-blur-sm" onClick={() => setIsSearchOpen(false)} />
          <div className="relative w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl border border-gray-100 p-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 border-b border-gray-100 pb-3">
              <Search className="h-5 w-5 text-gray-400 shrink-0" />
              <input
                type="text"
                autoFocus
                placeholder="Pesquisar por nome do produto, SKU ou fornecedor..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-sm outline-none text-[#111625]"
              />
              <button 
                onClick={() => {
                  setSearchQuery('');
                  setIsSearchOpen(false);
                }}
                className="rounded-full p-1 hover:bg-gray-100 text-gray-400"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            
            {searchQuery && (
              <div className="mt-3 max-h-60 overflow-y-auto divide-y divide-gray-50">
                {filteredProducts.slice(0, 5).map(p => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setSelectedProductDetails(p);
                      setIsSearchOpen(false);
                    }}
                    className="w-full text-left py-2 px-1 hover:bg-gray-50 flex items-center justify-between transition rounded"
                  >
                    <div>
                      <p className="text-xs font-bold text-[#111625]">{p.name}</p>
                      <p className="text-[10px] text-gray-400 font-mono">{p.sku} • {p.category}</p>
                    </div>
                    <span className="text-xs font-semibold bg-gray-100 px-2 py-0.5 rounded text-gray-600">
                      {p.quantity} un
                    </span>
                  </button>
                ))}
                {filteredProducts.length === 0 && (
                  <p className="text-xs text-center text-gray-400 py-4">Nenhum produto correspondente.</p>
                )}
              </div>
            )}
            
            <div className="mt-2 text-[11px] text-gray-400 flex justify-between">
              <span>Filtros ativos guiarão os resultados rápidos.</span>
              <button 
                onClick={() => {
                  setActiveTab('produtos');
                  setIsSearchOpen(false);
                }} 
                className="text-[#8A6E45] font-bold"
              >
                Ver todos os produtos →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SIDEBAR / DRAWER MENU */}
      {isSidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-[#111625]/60 backdrop-blur-sm" onClick={() => setIsSidebarOpen(false)} />
          <div className="relative w-full max-w-xs h-full bg-[#111625] text-white p-6 flex flex-col justify-between animate-in slide-in-from-left duration-200">
            <div>
              {/* Header inside sidebar */}
              <div className="flex items-center justify-between border-b border-gray-800 pb-5 mb-6">
                <div className="flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-transparent border border-[#C5A880]">
                    <span className="font-mono text-sm font-bold tracking-tight text-[#C5A880]">SE</span>
                  </div>
                  <span className="font-sans text-xl font-extrabold tracking-tight text-white">
                    SISEST
                  </span>
                </div>
                <button onClick={() => setIsSidebarOpen(false)} className="text-gray-400 hover:text-white">
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* User Profiling matching administrator look */}
              <div className="bg-gray-900/55 rounded-2xl p-4 border border-gray-800 mb-6 flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-[#C5A880]/20 flex items-center justify-center text-[#C5A880] border border-[#C5A880]/30 shrink-0">
                  <User className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-widest font-extrabold">ADMINISTRADOR</p>
                  <p className="text-sm font-bold text-white leading-tight">Mário de Andrade</p>
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-0.5 font-semibold">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Sessão Ativa
                  </span>
                </div>
              </div>

              {/* Navigation help links */}
              <div className="space-y-1">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider px-4 mb-2">Menu Principal</p>
                <button
                  onClick={() => { setActiveTab('inicio'); setIsSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
                    activeTab === 'inicio' ? 'bg-gray-600 text-white' : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <Package className="h-4 w-4" />
                  Painel Principal
                </button>
                <button
                  onClick={() => { setActiveTab('produtos'); setIsSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
                    activeTab === 'produtos' ? 'bg-gray-600 text-white' : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <Package className="h-4 w-4" />
                  Lista de Estoque
                </button>
                <button
                  onClick={() => { setActiveTab('movimentacoes'); setIsSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
                    activeTab === 'movimentacoes' ? 'bg-gray-600 text-white' : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <ArrowUpDown className="h-4 w-4" />
                  Registros de Lançamento
                </button>
                
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider px-4 mt-4 mb-2">Entidades</p>
                <button
                  onClick={() => { setActiveTab('tecnicos'); setIsSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
                    activeTab === 'tecnicos' ? 'bg-gray-600 text-white' : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <User className="h-4 w-4" />
                  Técnicos
                </button>
                <button
                  onClick={() => { setActiveTab('agencia'); setIsSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
                    activeTab === 'agencia' ? 'bg-gray-600 text-white' : 'text-gray-300 hover:bg-gray-800'
                  }`}
                >
                  <Building className="h-4 w-4" />
                  Agência
                </button>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="border-t border-gray-800 pt-4 space-y-2">
              <button
                onClick={handleResetData}
                className="w-full flex items-center justify-center gap-2 rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 py-2.5 text-xs font-semibold transition"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Reiniciar Banco Demo
              </button>
              <p className="text-[10px] text-center text-gray-500">
                SISEST Gestor de Estoque v1.4.2
              </p>
            </div>
          </div>
        </div>
      )}

      {/* NOTIFICATIONS DRAWER */}
      {isNotificationsOpen && (
        <NotificationDrawer
          notifications={notifications}
          onClose={() => setIsNotificationsOpen(false)}
          onMarkAsRead={handleMarkAsRead}
          onClearAll={handleClearNotifications}
        />
      )}

      {/* MAIN LAYOUT WRAPPER */}
      <main className="mx-auto w-full max-w-lg px-4 pt-6 space-y-6">

        {/* ========================================= */}
        {/* VIEW 1: HOME (INÍCIO)                     */}
        {/* ========================================= */}
        {activeTab === 'inicio' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-200">
            
            {/* GREETING TEXT FROM THE SCREENSHOT */}
            <div>
              <h1 className="text-3xl font-black uppercase tracking-tight text-[#111625]">
                Olá, ADMINISTRADOR!
              </h1>
              <p className="mt-1 text-sm font-medium text-gray-500">
                Gerencie seus produtos, estoque e movimentações em tempo real.
              </p>
            </div>

            {/* 4 DASHBOARD KPI CARDS FROM THE SCREENSHOT */}
            <div className="space-y-4">
              <MetricCard
                id="total-products"
                title="Estoque"
                value=""
                icon={Package}
                iconBgColor="bg-[#EEF4FF]"
                iconColor="text-blue-500"
                onClick={() => setActiveTab('produtos')}
              />

              <MetricCard
                id="total-entradas-saidas"
                title="Entrada/Saída"
                value=""
                icon={ArrowUpDown}
                iconBgColor="bg-[#F0FDF4]"
                iconColor="text-emerald-600"
                onClick={() => setActiveTab('movimentacoes')}
              />

              <MetricCard
                id="total-saidas"
                title="Cadastrar Peça"
                value=""
                icon={Plus}
                iconBgColor="bg-[#FEF2F2]"
                iconColor="text-red-500"
                onClick={() => {
                  setEditingProduct(null);
                  setProductFormOpen(true);
                }}
              />

              <MetricCard
                id="capital"
                title="Valor Total de Venda"
                value={formatBRL(totalInventoryValue)}
                icon={DollarSign}
                iconBgColor="bg-[#ECFDF5]"
                iconColor="text-emerald-500"
                onClick={() => setActiveTab('financeiro')}
              />
            </div>

            {/* QUICK ACTIONS ROW */}
            <div className="bg-gray-100 rounded-3xl p-5 border border-gray-200 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Ações Rápidas</h4>
                <p className="text-sm font-bold text-gray-900 mt-0.5">Precisa atualizar o estoque?</p>
              </div>
              <div className="flex gap-2">
                <button
                  id="btn-quick-mov"
                  onClick={() => {
                    setPreselectedMovementProductId(undefined);
                    setMovementFormOpen(true);
                  }}
                  className="flex h-11 items-center gap-1.5 px-4 rounded-xl bg-white border border-gray-200 text-xs font-extrabold text-gray-700 hover:bg-gray-50 active:scale-95 transition-all shadow-sm"
                >
                  <ArrowUpDown className="h-4 w-4 stroke-[2.5]" />
                  Movimentação
                </button>

                <button
                  id="btn-quick-add"
                  onClick={() => {
                    setEditingProduct(null);
                    setProductFormOpen(true);
                  }}
                  className="flex h-11 items-center gap-1.5 px-4 rounded-xl bg-gray-600 text-xs font-extrabold text-white hover:bg-gray-700 active:scale-95 transition-all shadow-md"
                >
                  <Plus className="h-4 w-4 stroke-[2.5]" />
                  Novo Item
                </button>
              </div>
            </div>

            {/* CRITICAL LOW STOCK MONITOR */}
            {lowStockProductsCount > 0 && (
              <div className="bg-white border border-gray-100 rounded-3xl p-5 shadow-[0_4px_20px_rgba(0,0,0,0.02)]">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xs font-extrabold uppercase tracking-widest text-gray-400 flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
                    Alerta de Reposição
                  </h3>
                  <button 
                    onClick={() => setActiveTab('alertas')}
                    className="text-xs font-bold text-gray-600 hover:underline"
                  >
                    Ver todos ({lowStockProductsCount})
                  </button>
                </div>

                <div className="space-y-3">
                  {products
                    .filter(p => p.quantity <= p.minQuantity)
                    .slice(0, 3)
                    .map(p => {
                      const percentage = Math.min(100, Math.round((p.quantity / (p.minQuantity * 2 || 10)) * 100));
                      return (
                        <div 
                          key={p.id} 
                          onClick={() => setSelectedProductDetails(p)}
                          className="group cursor-pointer bg-gray-50 hover:bg-amber-50/20 rounded-2xl p-3 border border-gray-100 transition-colors"
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-xs font-extrabold text-gray-900 group-hover:text-gray-700 transition-colors">{p.name}</p>
                              <p className="text-[10px] text-gray-400 font-mono mt-0.5">{p.sku} • {p.category}</p>
                            </div>
                            <span className={`text-xs font-black px-2 py-0.5 rounded ${
                              p.quantity === 0 
                                ? 'bg-red-100 text-red-600' 
                                : 'bg-amber-100 text-amber-700'
                            }`}>
                              {p.quantity === 0 ? 'SEM ESTOQUE' : `${p.quantity} un`}
                            </span>
                          </div>
                          
                          {/* Mini Progress Bar of current vs min */}
                          <div className="mt-3">
                            <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                              <span>Nível de Estoque</span>
                              <span>Mínimo: {p.minQuantity} un</span>
                            </div>
                            <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all duration-500 ${p.quantity === 0 ? 'w-0' : 'bg-amber-500'}`}
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* RECENT MOVEMENTS MINI-LOG */}
            <div className="bg-white border border-gray-100 rounded-3xl p-5 shadow-[0_4px_20px_rgba(0,0,0,0.02)]">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xs font-extrabold uppercase tracking-widest text-gray-400 flex items-center gap-1.5">
                  Últimos Lançamentos
                </h3>
                <button 
                  onClick={() => setActiveTab('movimentacoes')}
                  className="text-xs font-bold text-gray-600 hover:underline"
                >
                  Ver histórico
                </button>
              </div>

              <div className="space-y-2">
                {movements.slice(0, 4).map(m => (
                  <div key={m.id} className="flex items-center justify-between p-2.5 hover:bg-gray-50 rounded-xl transition">
                    <div className="flex items-center gap-3">
                      <div className={`p-1.5 rounded-lg shrink-0 ${
                        m.type === 'ENTRADA' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'
                      }`}>
                        {m.type === 'ENTRADA' ? (
                          <ArrowUpRight className="h-4 w-4 stroke-[2.5]" />
                        ) : (
                          <ArrowDownRight className="h-4 w-4 stroke-[2.5]" />
                        )}
                      </div>
                      <div className="text-left">
                        <p className="text-xs font-bold text-gray-900 truncate max-w-[180px]">{m.productName}</p>
                        <p className="text-[10px] text-gray-400 mt-0.5">
                          {m.reason} {m.estoque ? `(${m.estoque})` : ''} {m.serie ? `• Série: ${m.serie}` : ''} • {m.responsible}
                        </p>
                      </div>
                    </div>
                    <span className={`text-xs font-extrabold ${
                      m.type === 'ENTRADA' ? 'text-emerald-600' : 'text-red-500'
                    }`}>
                      {m.type === 'ENTRADA' ? '+' : '-'}{m.quantity} un
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ========================================= */}
        {/* VIEW 2: PRODUCTS MANAGER (PRODUTOS)        */}
        {/* ========================================= */}
        {activeTab === 'produtos' && (
          <div className="space-y-5 animate-in fade-in slide-in-from-bottom-3 duration-200">
            
            {/* View Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-black text-gray-900">Cadastro de Produtos</h1>
                <p className="text-xs text-gray-500">Visualize, filtre e gerencie seus SKUs cadastrados.</p>
              </div>
              <button
                id="btn-add-product"
                onClick={() => {
                  setEditingProduct(null);
                  setProductFormOpen(true);
                }}
                className="flex items-center justify-center h-10 w-10 rounded-xl bg-gray-600 text-white hover:bg-gray-700 transition shadow active:scale-95"
              >
                <Plus className="h-5 w-5 stroke-[2.5]" />
              </button>
            </div>

            {/* Quick Search and Category filters */}
            <div className="bg-white rounded-3xl p-4 border border-gray-100 space-y-3 shadow-sm">
              
              {/* Inner Search Field */}
              <div className="relative flex items-center">
                <Search className="absolute left-3.5 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Buscar por SKU, nome ou fornecedor..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-gray-50 rounded-2xl pl-10 pr-4 py-2.5 text-xs outline-none focus:bg-white focus:ring-1 focus:ring-gray-500/30 transition border border-gray-150"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>

              {/* Categorias quick scroll pills */}
              <div>
                <span className="block text-[10px] font-extrabold uppercase tracking-wider text-gray-400 mb-1.5">Categorias</span>
                <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar select-none">
                  <button
                    onClick={() => setCategoryFilter('Todas')}
                    className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
                      categoryFilter === 'Todas'
                        ? 'bg-gray-600 text-white'
                        : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
                    }`}
                  >
                    Todas ({products.length})
                  </button>
                  {CATEGORIES.map(cat => {
                    const count = products.filter(p => p.category === cat).length;
                    return (
                      <button
                        key={cat}
                        onClick={() => setCategoryFilter(cat)}
                        className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
                          categoryFilter === cat
                            ? 'bg-gray-600 text-white'
                            : 'bg-gray-50 text-gray-500 hover:bg-gray-100'
                        }`}
                      >
                        {cat} ({count})
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Alerta stock status filter */}
              <div className="border-t border-gray-100 pt-2.5 flex items-center justify-between text-xs">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-400">Nível do Estoque</span>
                <div className="flex gap-2">
                  {[
                    { id: 'Todos', label: 'Todos' },
                    { id: 'Baixo', label: 'Estoque Baixo' },
                    { id: 'Esgotado', label: 'Esgotado' }
                  ].map(status => (
                    <button
                      key={status.id}
                      onClick={() => setStockStatusFilter(status.id)}
                      className={`font-semibold px-2.5 py-1 rounded-lg transition-colors ${
                        stockStatusFilter === status.id
                          ? 'bg-gray-100 text-gray-700 border border-gray-200'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      {status.label}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* List results of products */}
            <div className="space-y-3">
              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-3xl p-10 border border-gray-100 text-center flex flex-col items-center">
                  <Package className="h-12 w-12 text-gray-300 stroke-[1.5] mb-2" />
                  <p className="text-sm font-bold text-gray-500">Nenhum produto encontrado</p>
                  <p className="text-xs text-gray-400 mt-1">Experimente alterar as palavras de busca ou limpar filtros.</p>
                  <button 
                    onClick={() => {
                      setSearchQuery('');
                      setCategoryFilter('Todas');
                      setStockStatusFilter('Todos');
                    }}
                    className="mt-4 px-4 py-2 bg-gray-50 border border-gray-200 text-xs font-bold text-gray-700 rounded-xl hover:bg-gray-100 transition"
                  >
                    Limpar Filtros
                  </button>
                </div>
              ) : (
                filteredProducts.map(p => {
                  const isLow = p.quantity <= p.minQuantity && p.quantity > 0;
                  const isOOS = p.quantity === 0;
                  
                  return (
                    <div
                      key={p.id}
                      onClick={() => setSelectedProductDetails(p)}
                      className="group bg-white rounded-3xl p-4 border border-gray-100 hover:shadow-md transition duration-200 cursor-pointer flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3.5 flex-1 min-w-0">
                        {/* Letter/Color Badge */}
                        <div className={`h-11 w-11 rounded-2xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          isOOS 
                            ? 'bg-red-50 text-red-500 border border-red-100' 
                            : isLow 
                              ? 'bg-amber-50 text-amber-500 border border-amber-100' 
                              : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                        }`}>
                          {p.category.substring(0, 2).toUpperCase()}
                        </div>

                        {/* Text description details */}
                        <div className="text-left min-w-0 flex-1">
                          <p className="text-xs font-black text-gray-900 truncate group-hover:text-gray-700 transition-colors">{p.name}</p>
                          <div className="flex items-center gap-2 mt-0.5 text-[10px] text-gray-400">
                            <span className="font-mono font-bold tracking-tight bg-gray-50 px-1 rounded">{p.sku}</span>
                            <span>•</span>
                            <span>{p.category}</span>
                            {p.estoque && (
                              <>
                                <span>•</span>
                                <span className="font-bold text-gray-700 bg-gray-100 px-1.5 py-0.5 rounded-full text-[9px]">
                                  {p.estoque}
                                </span>
                              </>
                            )}
                          </div>
                          
                          {/* Price tags summary */}
                          <div className="flex items-center gap-2.5 mt-1.5 text-xs">
                            <span className="font-extrabold text-gray-800">{formatBRL(p.salePrice)}</span>
                            {p.location && (
                              <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                                <MapPin className="h-3 w-3" />
                                {p.location}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Right Stock Status count & Arrow */}
                      <div className="flex items-center gap-3 shrink-0 ml-4">
                        <div className="text-right">
                          <span className={`text-base font-black ${
                            isOOS 
                              ? 'text-red-500' 
                              : isLow 
                                ? 'text-amber-500 font-extrabold' 
                                : 'text-gray-800'
                          }`}>
                            {p.quantity} un
                          </span>
                          
                          <p className={`text-[9px] mt-0.5 font-bold ${
                            isOOS 
                              ? 'text-red-400' 
                              : isLow 
                                ? 'text-amber-500 animate-pulse' 
                                : 'text-emerald-500'
                          }`}>
                            {isOOS ? 'Esgotado' : isLow ? 'Estoque Baixo' : 'Normal'}
                          </p>
                        </div>
                        <ChevronRight className="h-5 w-5 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
                      </div>

                    </div>
                  );
                })
              )}
            </div>

          </div>
        )}

        {/* ========================================= */}
        {/* VIEW 3: MOVEMENTS LIST (MOVIMENTAÇÕES)    */}
        {/* ========================================= */}
        {activeTab === 'movimentacoes' && (
          <div className="space-y-5 animate-in fade-in slide-in-from-bottom-3 duration-200">
            
            {/* View Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-black text-gray-900">Lançamentos de Estoque</h1>
                <p className="text-xs text-gray-500">Histórico completo de entradas e saídas de itens.</p>
              </div>
              
              <button
                id="btn-add-movement"
                onClick={() => {
                  setPreselectedMovementProductId(undefined);
                  setMovementFormOpen(true);
                }}
                className="flex items-center gap-1.5 px-4 h-11 rounded-xl bg-gray-600 text-xs font-extrabold text-white hover:bg-gray-700 active:scale-95 transition-all shadow-md"
              >
                <Plus className="h-4 w-4 stroke-[2.5]" />
                Lançar Movimento
              </button>
            </div>

            {/* List of movements */}
            <div className="space-y-3">
              {movements.length === 0 ? (
                <div className="bg-white rounded-3xl p-10 border border-gray-100 text-center">
                  <ArrowUpDown className="h-12 w-12 text-gray-300 stroke-[1.5] mb-2 mx-auto" />
                  <p className="text-sm font-bold text-gray-500">Nenhum lançamento efetuado</p>
                  <p className="text-xs text-gray-400 mt-1">Adicione produtos e registre as primeiras entradas/saídas.</p>
                </div>
              ) : (
                movements.map(m => {
                  const isEntrada = m.type === 'ENTRADA';
                  return (
                    <div
                      key={m.id}
                      className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm flex gap-3.5 items-start text-left"
                    >
                      {/* Movement Icon Status */}
                      <div className={`mt-0.5 p-2 rounded-xl ${
                        isEntrada ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-500'
                      }`}>
                        {isEntrada ? (
                          <ArrowUpRight className="h-5 w-5 stroke-[2.5]" />
                        ) : (
                          <ArrowDownRight className="h-5 w-5 stroke-[2.5]" />
                        )}
                      </div>

                      {/* Movement Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start gap-1">
                          <p className="text-xs font-black text-gray-900 truncate">
                            {m.productName}
                          </p>
                          <span className={`text-sm font-black shrink-0 ${
                            isEntrada ? 'text-emerald-600' : 'text-red-500'
                          }`}>
                            {isEntrada ? '+' : '-'}{m.quantity} un
                          </span>
                        </div>
                        
                        <p className="text-xs text-gray-600 mt-1 font-semibold leading-snug">
                          Motivo: {m.reason}
                        </p>

                        {(m.estoque || m.serie) && (
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {m.estoque && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-700 border border-gray-200">
                                Estoque: {m.estoque}
                              </span>
                            )}
                            {m.serie && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-600 border border-gray-200">
                                Série: {m.serie}
                              </span>
                            )}
                          </div>
                        )}

                        <div className="flex items-center justify-between mt-3 text-[10px] text-gray-400 border-t border-gray-50 pt-2">
                          <span className="flex items-center gap-1">
                            <User className="h-3.5 w-3.5" />
                            Resp: <strong className="text-gray-500 font-bold">{m.responsible}</strong>
                          </span>
                          <span className="flex items-center gap-1 font-mono">
                            <Clock className="h-3.5 w-3.5" />
                            {new Date(m.date).toLocaleString('pt-BR')}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

          </div>
        )}

        {/* ========================================= */}
        {/* VIEW 4: LOW STOCK ALERTS (ALERTAS)         */}
        {/* ========================================= */}
        {activeTab === 'alertas' && (
          <div className="space-y-5 animate-in fade-in slide-in-from-bottom-3 duration-200">
            
            {/* View Header */}
            <div>
              <h1 className="text-2xl font-black text-gray-900">Alertas de Reposição</h1>
              <p className="text-xs text-gray-500">Produtos que estão abaixo do estoque mínimo ideal.</p>
            </div>

            {/* Low stock indicators summary card */}
            <div className="bg-amber-50 border border-amber-200/50 rounded-3xl p-5 flex items-center gap-4 text-left">
              <div className="h-12 w-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                <AlertTriangle className="h-6 w-6 stroke-[2.5]" />
              </div>
              <div>
                <p className="text-xs font-bold text-amber-800 uppercase tracking-wider">Atenção Necessária</p>
                <p className="text-sm font-bold text-gray-900 leading-tight mt-0.5">
                  Há {lowStockProductsCount} produto(s) com estoque crítico. Providencie a compra ou reposição dos lotes.
                </p>
              </div>
            </div>

            {/* List of critical products only */}
            <div className="space-y-3">
              {products.filter(p => p.quantity <= p.minQuantity).length === 0 ? (
                <div className="bg-white rounded-3xl p-10 border border-gray-100 text-center">
                  <FileCheck2 className="h-12 w-12 text-emerald-400 stroke-[1.5] mb-2 mx-auto" />
                  <p className="text-sm font-bold text-gray-600">Nenhum produto em alerta!</p>
                  <p className="text-xs text-gray-400 mt-1">Parabéns! Todos os SKUs encontram-se acima da margem crítica de segurança.</p>
                </div>
              ) : (
                products
                  .filter(p => p.quantity <= p.minQuantity)
                  .map(p => {
                    const isOOS = p.quantity === 0;
                    const deficit = p.minQuantity - p.quantity;
                    return (
                      <div
                        key={p.id}
                        className="bg-white rounded-3xl p-5 border border-gray-100 shadow-sm space-y-4"
                      >
                        {/* Title Row */}
                        <div className="flex justify-between items-start">
                          <div className="text-left">
                            <h3 className="text-sm font-black text-gray-900">{p.name}</h3>
                            <p className="text-[10px] text-gray-400 font-mono mt-0.5">{p.sku} • {p.category}</p>
                          </div>
                          <span className={`text-xs font-extrabold px-2.5 py-0.5 rounded ${
                            isOOS ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-700'
                          }`}>
                            {isOOS ? 'ESGOTADO' : `${p.quantity} un restantes`}
                          </span>
                        </div>

                        {/* Deficit / Supply info */}
                        <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100 flex items-center justify-between text-left">
                          <div className="text-xs text-gray-500">
                            <span className="block text-[10px] text-gray-400 uppercase font-bold">Déficit crítico</span>
                            Precisa de pelo menos <strong className="text-gray-800 font-black">{deficit} un</strong> para atingir o mínimo.
                          </div>
                          
                          {/* Easy restocking trigger */}
                          <button
                            onClick={() => {
                              setPreselectedMovementProductId(p.id);
                              setMovementFormOpen(true);
                            }}
                            className="bg-gray-600 hover:bg-gray-700 text-white text-xs font-extrabold px-3 py-2 rounded-xl transition"
                          >
                            Repor Estoque
                          </button>
                        </div>

                        {/* Location and supplier logs */}
                        <div className="flex items-center justify-between text-[10px] text-gray-400 border-t border-gray-50 pt-3">
                          <span className="flex items-center gap-1">
                            <Building className="h-3.5 w-3.5" />
                            Fornecedor: <strong className="text-gray-500">{p.supplier || 'Não especificado'}</strong>
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3.5 w-3.5" />
                            Setor: <strong className="text-gray-500">{p.location || 'Sem local'}</strong>
                          </span>
                        </div>
                      </div>
                    );
                  })
              )}
            </div>

          </div>
        )}

        {/* ========================================= */}
        {/* VIEW 5: FINANCE & METRICS (FINANCEIRO)    */}
        {/* ========================================= */}
        {activeTab === 'financeiro' && (
          <div className="space-y-5 animate-in fade-in slide-in-from-bottom-3 duration-200">
            
            {/* View Header */}
            <div>
              <h1 className="text-2xl font-black text-gray-900">Valoração de Estoque</h1>
              <p className="text-xs text-gray-500">Métricas de capital, margens e lucro potencial em estoque.</p>
            </div>

            {/* Main Financial breakdown layout */}
            <div className="bg-gray-100 rounded-3xl p-5 border border-gray-200 space-y-4">
              <div className="text-left">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-gray-400">Patrimônio Líquido de Estoque</span>
                <h2 className="text-3xl font-black text-gray-900 mt-1">{formatBRL(totalInventoryValue)}</h2>
                <p className="text-xs text-gray-500 mt-1">Preço final de venda acumulado.</p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-gray-200">
                <div className="text-left">
                  <span className="text-[10px] text-gray-400 block font-bold uppercase">Custo de Aquisição</span>
                  <span className="text-base font-bold text-gray-800">{formatBRL(totalCostValue)}</span>
                </div>
                <div className="text-left">
                  <span className="text-[10px] text-gray-400 block font-bold uppercase">Lucro Projetado (Net)</span>
                  <span className="text-base font-bold text-emerald-600 flex items-center gap-1">
                    <TrendingUp className="h-4 w-4" />
                    {formatBRL(totalPotentialProfit)}
                  </span>
                </div>
              </div>
            </div>

            {/* Margins details block */}
            <div className="bg-white rounded-3xl p-5 border border-gray-100 shadow-sm space-y-4">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-gray-400 text-left">Desempenho por Categoria</h3>
              
              <div className="space-y-4">
                {CATEGORIES.map(cat => {
                  const catProducts = products.filter(p => p.category === cat);
                  const catValue = catProducts.reduce((sum, p) => sum + (p.quantity * p.salePrice), 0);
                  const totalValueSafe = totalInventoryValue || 1;
                  const sharePercentage = Math.round((catValue / totalValueSafe) * 100);
                  
                  if (catProducts.length === 0) return null;

                  return (
                    <div key={cat} className="space-y-1.5 text-left">
                      <div className="flex justify-between items-end text-xs">
                        <span className="font-bold text-gray-900">{cat}</span>
                        <span className="text-gray-500 font-mono">
                          {formatBRL(catValue)} <strong className="text-gray-700 font-black">({sharePercentage}%)</strong>
                        </span>
                      </div>
                      
                      {/* Responsive Progress Percentage indicator */}
                      <div className="w-full h-2 bg-gray-50 border border-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gray-600 rounded-full"
                          style={{ width: `${sharePercentage}%` }}
                        />
                      </div>
                      <p className="text-[10px] text-gray-400">
                        {catProducts.length} SKU(s) cadastrados nessa categoria.
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Financial Info Warning */}
            <div className="bg-gray-50 border border-gray-150 rounded-2xl p-4 text-xs text-gray-500 text-left flex gap-3 items-start">
              <FileText className="h-5 w-5 text-gray-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-gray-900 block mb-0.5">Nota Importante</strong>
                O cálculo de patrimônio baseia-se em (Quantidade em estoque * Preço). Ajustes de perda ou descontos promocionais não estão refletidos nestas projeções automáticas de venda.
              </div>
            </div>

          </div>
        )}

        {/* ========================================= */}
        {/* VIEW 6: TÉCNICOS                          */}
        {/* ========================================= */}
        {activeTab === 'tecnicos' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-200 text-left">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-black text-gray-900">Controle de Técnicos</h1>
                <p className="text-xs text-gray-500">Cadastro de equipe e histórico de retiradas pelo estoque Wyntech.</p>
              </div>
              <button
                onClick={() => setTechnicianFormOpen(true)}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-gray-600 text-white hover:bg-gray-700 font-bold text-sm shadow-sm transition active:scale-95"
              >
                <Plus className="h-4 w-4" />
                Cadastrar Técnico
              </button>
            </div>

            {/* List of Registered Technicians */}
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-gray-50 bg-gray-50/50 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-gray-900">Técnicos Cadastrados</h3>
                  <p className="text-xs text-gray-400">Profissionais aptos a realizar retiradas de peças para ordens de serviço.</p>
                </div>
                <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-gray-100 text-gray-700 border border-gray-200">
                  {technicians.length} cadastrado(s)
                </span>
              </div>

              {technicians.length === 0 ? (
                <div className="p-10 text-center text-gray-400 text-sm">
                  <User className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  Nenhum técnico cadastrado ainda. Clique em "Cadastrar Técnico" acima para registrar o primeiro.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="bg-gray-50 text-xs font-extrabold uppercase tracking-wider text-gray-400 border-b border-gray-100">
                        <th className="px-6 py-3">Matrícula</th>
                        <th className="px-6 py-3">Nome</th>
                        <th className="px-6 py-3 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {technicians.map((tech) => (
                        <tr key={tech.id} className="hover:bg-gray-50/50 transition">
                          <td className="px-6 py-4 font-mono font-bold text-gray-700 text-xs col-span-1">
                            {tech.matricula}
                          </td>
                          <td className="px-6 py-4 font-semibold text-gray-900">
                            {tech.nome}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setEditingTechnician(tech)}
                                className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition"
                                title="Editar Técnico"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteTechnician(tech.id)}
                                className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition"
                                title="Remover Técnico"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* List of Technicians with actual Movements/Withdrawals */}
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-gray-50 bg-gray-50/50">
                <h3 className="font-bold text-gray-900">Histórico de Retiradas</h3>
                <p className="text-xs text-gray-400">Resumo de retiradas realizadas por técnico no estoque Wyntech.</p>
              </div>

              {movements.filter(m => m.tecnico).length === 0 ? (
                <div className="p-10 text-center text-gray-400 text-sm">
                  <User className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  Nenhum registro de retirada por técnicos até o momento.
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {Array.from(new Set(movements.map(m => m.tecnico).filter(Boolean))).map(tecName => {
                    const tecMovements = movements.filter(m => m.tecnico === tecName);
                    const totalParts = tecMovements.reduce((acc, m) => acc + m.quantity, 0);
                    const uniqueChamados = Array.from(new Set(tecMovements.map(m => m.chamado).filter(Boolean)));
                    const lastMov = tecMovements.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

                    return (
                      <div key={tecName} className="p-5 hover:bg-gray-50 transition-colors">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div>
                            <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
                              <span className="h-2.5 w-2.5 rounded-full bg-gray-600" />
                              {tecName}
                            </h4>
                            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1.5 text-xs text-gray-500">
                              <span><strong>Chamados Atendidos:</strong> {uniqueChamados.join(', ') || 'Nenhum'}</span>
                              <span><strong>Última Retirada:</strong> {lastMov ? new Date(lastMov.date).toLocaleDateString('pt-BR') : '-'}</span>
                            </div>
                          </div>
                          <div className="text-left md:text-right">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-700 border border-gray-200">
                              {totalParts} peça(s) retirada(s)
                            </span>
                          </div>
                        </div>

                        {/* Sub-table with withdrawal details */}
                        <div className="mt-4 bg-gray-50/50 rounded-2xl border border-gray-100 overflow-hidden">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead>
                              <tr className="bg-gray-100/70 text-[10px] font-extrabold uppercase tracking-wider text-gray-400">
                                <th className="px-4 py-2">Chamado</th>
                                <th className="px-4 py-2">Peça</th>
                                <th className="px-4 py-2 text-center">Qtd</th>
                                <th className="px-4 py-2">Data</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {tecMovements.map(mov => (
                                <tr key={mov.id} className="hover:bg-white transition-colors">
                                  <td className="px-4 py-2 font-mono text-gray-700 font-semibold">{mov.chamado}</td>
                                  <td className="px-4 py-2 text-gray-700 font-medium">{mov.productName}</td>
                                  <td className="px-4 py-2 text-center text-gray-950 font-bold">{mov.quantity}</td>
                                  <td className="px-4 py-2 text-gray-400">{new Date(mov.date).toLocaleDateString('pt-BR')}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ========================================= */}
        {/* VIEW 7: AGÊNCIA                           */}
        {/* ========================================= */}
        {activeTab === 'agencia' && (
          <div className="space-y-5 animate-in fade-in slide-in-from-bottom-3 duration-200 text-left">
            <div>
              <h1 className="text-2xl font-black text-gray-900">Agências & Destinos</h1>
              <p className="text-xs text-gray-500">Controle de unidades de destino e usuários receptores das peças (Estoque CAIXA).</p>
            </div>

            {/* List of Agencies */}
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-gray-50 bg-gray-50/50">
                <h3 className="font-bold text-gray-900">Agências Destinatárias</h3>
                <p className="text-xs text-gray-400">Unidades que receberam suprimentos de peças da CAIXA.</p>
              </div>

              {movements.filter(m => m.unidadeDestino).length === 0 ? (
                <div className="p-8 text-center text-gray-400 text-sm">
                  <Building className="h-12 w-12 mx-auto text-gray-300 mb-3" />
                  Nenhuma agência destinatária registrada no momento.
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {Array.from(new Set(movements.map(m => m.unidadeDestino).filter(Boolean))).map(ageName => {
                    const ageMovements = movements.filter(m => m.unidadeDestino === ageName);
                    const totalParts = ageMovements.reduce((acc, m) => acc + m.quantity, 0);
                    const usersInfo = Array.from(new Set(ageMovements.map(m => `${m.usuario} (${m.matricula})`).filter(u => u && !u.startsWith('undefined'))));
                    const lastMov = ageMovements.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

                    return (
                      <div key={ageName} className="p-5 hover:bg-gray-50 transition-colors">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div>
                            <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
                              <Building className="h-4 w-4 text-gray-500" />
                              {ageName}
                            </h4>
                            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1.5 text-xs text-gray-500">
                              <span><strong>Usuários (Matrícula):</strong> {usersInfo.join(', ') || 'Nenhum'}</span>
                              <span><strong>Último Envio:</strong> {lastMov ? new Date(lastMov.date).toLocaleDateString('pt-BR') : '-'}</span>
                            </div>
                          </div>
                          <div className="text-left md:text-right">
                            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-700 border border-gray-200">
                              {totalParts} peça(s) enviada(s)
                            </span>
                          </div>
                        </div>

                        {/* Sub-table with agency details */}
                        <div className="mt-4 bg-gray-50/50 rounded-2xl border border-gray-100 overflow-hidden">
                          <table className="w-full text-left border-collapse text-xs">
                            <thead>
                              <tr className="bg-gray-100/70 text-[10px] font-extrabold uppercase tracking-wider text-gray-400">
                                <th className="px-4 py-2">Recebido por</th>
                                <th className="px-4 py-2">Peça</th>
                                <th className="px-4 py-2 text-center">Qtd</th>
                                <th className="px-4 py-2">Data</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {ageMovements.map(mov => (
                                <tr key={mov.id} className="hover:bg-white transition-colors">
                                  <td className="px-4 py-2 text-gray-700 font-medium">{mov.usuario} <span className="text-gray-400 font-mono text-[10px]">({mov.matricula})</span></td>
                                  <td className="px-4 py-2 text-gray-700 font-medium">{mov.productName}</td>
                                  <td className="px-4 py-2 text-center text-gray-950 font-bold">{mov.quantity}</td>
                                  <td className="px-4 py-2 text-gray-400">{new Date(mov.date).toLocaleDateString('pt-BR')}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

      </main>

      {/* FIXED BOTTOM NAVIGATION BAR */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        lowStockCount={lowStockProductsCount}
      />

      {/* ========================================= */}
      {/* MODAL: PRODUCT DETAILS (FICHA TÉCNICA)    */}
      {/* ========================================= */}
      {selectedProductDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm" 
            onClick={() => setSelectedProductDetails(null)} 
          />

          <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl border border-gray-100 max-h-[85vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-gray-700 bg-gray-100 px-2 py-0.5 rounded-full">
                  Ficha Técnica
                </span>
                <h3 className="text-base font-black text-gray-900 mt-1.5 truncate max-w-[280px]">
                  {selectedProductDetails.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedProductDetails(null)}
                className="rounded-full p-1.5 hover:bg-gray-200 text-gray-400"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable details body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 text-left">
              
              {/* SKU, Category & Location info row */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100">
                  <span className="block text-[9px] text-gray-400 font-bold uppercase">Código SKU</span>
                  <span className="text-xs font-mono font-bold text-gray-800">{selectedProductDetails.sku}</span>
                </div>
                <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100">
                  <span className="block text-[9px] text-gray-400 font-bold uppercase">Categoria</span>
                  <span className="text-xs font-bold text-gray-800">{selectedProductDetails.category}</span>
                </div>
              </div>

              {/* Stock quantities summary */}
              <div className="bg-amber-50/40 border border-amber-100 rounded-3xl p-4 flex items-center justify-between">
                <div>
                  <span className="block text-[9px] text-amber-700/80 font-bold uppercase">Estoque Disponível</span>
                  <span className="text-2xl font-black text-gray-900">{selectedProductDetails.quantity} <span className="text-sm font-bold text-gray-500">unidades</span></span>
                </div>
                <div className="text-right">
                  <span className="block text-[9px] text-gray-400 font-bold uppercase">Estoque Mínimo</span>
                  <span className="text-sm font-bold text-gray-600">{selectedProductDetails.minQuantity} un</span>
                </div>
              </div>

              {/* Cost & Sale details */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100">
                  <span className="block text-[9px] text-gray-400 font-bold uppercase">Preço de Custo</span>
                  <span className="text-xs font-bold text-gray-800">{formatBRL(selectedProductDetails.costPrice)}</span>
                </div>
                <div className="bg-gray-50 rounded-2xl p-3 border border-gray-100">
                  <span className="block text-[9px] text-gray-400 font-bold uppercase">Preço de Venda</span>
                  <span className="text-xs font-bold text-emerald-600 font-black">{formatBRL(selectedProductDetails.salePrice)}</span>
                </div>
              </div>

              {/* Potential markup info box */}
              <div className="bg-emerald-50/20 border border-emerald-100 rounded-2xl p-3 text-xs flex justify-between items-center text-emerald-800">
                <span>Margem de Lucro Bruto:</span>
                <strong className="font-extrabold text-sm">
                  {selectedProductDetails.costPrice > 0 
                    ? `${Math.round(((selectedProductDetails.salePrice - selectedProductDetails.costPrice) / selectedProductDetails.salePrice) * 100)}%` 
                    : '100%'}
                </strong>
              </div>

              {/* Location & Supplier */}
              <div className="space-y-2 text-xs">
                {selectedProductDetails.estoque && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Package className="h-4 w-4 text-gray-500 shrink-0" />
                    <span>Estoque: <strong>{selectedProductDetails.estoque}</strong></span>
                  </div>
                )}
                {selectedProductDetails.location && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="h-4 w-4 text-gray-400 shrink-0" />
                    <span>Local: <strong>{selectedProductDetails.location}</strong></span>
                  </div>
                )}
                {selectedProductDetails.supplier && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Building className="h-4 w-4 text-gray-400 shrink-0" />
                    <span>Fornecedor: <strong>{selectedProductDetails.supplier}</strong></span>
                  </div>
                )}
                {selectedProductDetails.description && (
                  <div className="flex gap-2 items-start text-gray-600 border-t border-gray-50 pt-3 mt-3">
                    <FileText className="h-4 w-4 text-gray-400 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">Descrição: <strong className="font-medium text-gray-700">{selectedProductDetails.description}</strong></p>
                  </div>
                )}
              </div>

              {/* PRODUCT MOVEMENT HISTORY LOGS */}
              <div className="border-t border-gray-100 pt-3 mt-4">
                <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-gray-400 mb-2 flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5" />
                  Histórico deste Produto
                </h4>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {movements.filter(m => m.productId === selectedProductDetails.id).length === 0 ? (
                    <p className="text-[11px] text-gray-400 italic">Sem lançamentos recentes registrados para este item.</p>
                  ) : (
                    movements
                      .filter(m => m.productId === selectedProductDetails.id)
                      .map(m => (
                        <div key={m.id} className="flex justify-between items-center text-[11px] bg-gray-50 p-2 rounded-lg">
                          <div className="min-w-0">
                            <span className={`font-bold ${m.type === 'ENTRADA' ? 'text-emerald-600' : 'text-red-500'}`}>
                              {m.type === 'ENTRADA' ? 'ENTRADA' : 'SAÍDA'}
                            </span>
                            <span className="text-gray-400 font-mono ml-2">
                              {new Date(m.date).toLocaleDateString('pt-BR')}
                            </span>
                            <p className="text-gray-500 truncate mt-0.5">{m.reason}</p>
                          </div>
                          <span className={`font-extrabold shrink-0 ${m.type === 'ENTRADA' ? 'text-emerald-600' : 'text-red-500'}`}>
                            {m.type === 'ENTRADA' ? '+' : '-'}{m.quantity}
                          </span>
                        </div>
                      ))
                  )}
                </div>
              </div>

              {/* Action buttons on details view */}
              <div className="flex gap-2 pt-3 border-t border-gray-100">
                <button
                  onClick={() => {
                    setEditingProduct(selectedProductDetails);
                    setSelectedProductDetails(null);
                    setProductFormOpen(true);
                  }}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-extrabold text-gray-700 hover:bg-gray-50 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                >
                  <Edit className="h-3.5 w-3.5" />
                  Editar Cadastro
                </button>
                
                <button
                  onClick={() => {
                    setPreselectedMovementProductId(selectedProductDetails.id);
                    setMovementFormOpen(true);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-gray-100 border border-gray-200 text-xs font-extrabold text-gray-700 hover:bg-gray-200 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                >
                  <ArrowUpDown className="h-3.5 w-3.5" />
                  Lançar Movimento
                </button>

                <button
                  onClick={() => handleDeleteProduct(selectedProductDetails.id)}
                  title="Excluir Produto"
                  className="rounded-xl p-2.5 border border-red-200 text-red-500 hover:bg-red-50 active:scale-95 transition-all"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ========================================= */}
      {/* MODAL: PRODUCT FORM                       */}
      {/* ========================================= */}
      {productFormOpen && (
        <ProductForm
          product={editingProduct}
          onSave={handleSaveProduct}
          onClose={() => {
            setProductFormOpen(false);
            setEditingProduct(null);
          }}
        />
      )}

      {/* ========================================= */}
      {/* MODAL: MOVEMENT FORM                      */}
      {/* ========================================= */}
      {movementFormOpen && (
        <MovementForm
          products={products}
          selectedProductId={preselectedMovementProductId}
          technicians={technicians}
          onSave={handleSaveMovement}
          onClose={() => {
            setMovementFormOpen(false);
            setPreselectedMovementProductId(undefined);
          }}
        />
      )}

      {/* ========================================= */}
      {/* MODAL: TECHNICIAN FORM                    */}
      {/* ========================================= */}
      {(technicianFormOpen || editingTechnician !== null) && (
        <TechnicianForm
          initialData={editingTechnician || undefined}
          onSave={handleSaveTechnician}
          onClose={() => {
            setTechnicianFormOpen(false);
            setEditingTechnician(null);
          }}
        />
      )}

      {/* ========================================= */}
      {/* MODAL: WHATSAPP                           */}
      {/* ========================================= */}
      {whatsappPromptMovement && (
        <WhatsAppModal
          movement={whatsappPromptMovement}
          technicians={technicians}
          onClose={() => setWhatsappPromptMovement(null)}
        />
      )}

    </div>
  );
}
