import React, { useState, useEffect } from 'react';
import { X, ArrowDownCircle, ArrowUpCircle, ChevronDown } from 'lucide-react';
import { Product, Movement, Technician } from '../types';

interface MovementFormProps {
  products: Product[];
  selectedProductId?: string; // Optional pre-selected product
  technicians?: Technician[];
  onSave: (movement: Omit<Movement, 'id' | 'date'>) => void;
  onClose: () => void;
}

const COMMON_REASONS = {
  ENTRADA: [
    'Compra de fornecedor',
    'Ajuste de estoque (Sobra)',
    'Retorno de cliente / Devolução',
    'Brinde / Amostra recebida',
    'Outros'
  ],
  SAÍDA: [
    'Venda realizada',
    'Ajuste de estoque (Divergência)',
    'Perda, roubo ou quebra',
    'Uso interno / Amostragem',
    'Envio para assistência / Garantia',
    'Outros'
  ]
};

export default function MovementForm({
  products,
  selectedProductId,
  technicians = [],
  onSave,
  onClose
}: MovementFormProps) {
  const [productId, setProductId] = useState('');
  const [type, setType] = useState<'ENTRADA' | 'SAÍDA'>('ENTRADA');
  const [quantity, setQuantity] = useState(1);
  const [reason, setReason] = useState(COMMON_REASONS.ENTRADA[0]);
  const [customReason, setCustomReason] = useState('');
  const [responsible, setResponsible] = useState('Administrador');
  const [estoque, setEstoque] = useState<'CAIXA' | 'Wyntech'>('CAIXA');
  const [isEstoqueDropdownOpen, setIsEstoqueDropdownOpen] = useState(false);
  const [isProductDropdownOpen, setIsProductDropdownOpen] = useState(false);
  const [tecnico, setTecnico] = useState('');
  const [showCustomTecnico, setShowCustomTecnico] = useState(false);
  const [customTecnico, setCustomTecnico] = useState('');
  const [chamado, setChamado] = useState('');
  const [unidadeDestino, setUnidadeDestino] = useState('');
  const [usuario, setUsuario] = useState('');
  const [matricula, setMatricula] = useState('');
  const [serie, setSerie] = useState('');

  // Find the currently selected product
  const currentProduct = products.find(p => p.id === productId);

  // Sync selected product with selected stock
  useEffect(() => {
    if (selectedProductId) {
      setProductId(selectedProductId);
      const prod = products.find(p => p.id === selectedProductId);
      if (prod && prod.estoque) {
        setEstoque(prod.estoque);
      }
    } else {
      const valid = products.filter(p => (p.estoque || 'CAIXA') === estoque);
      if (valid.length > 0) {
        const isStillValid = valid.some(p => p.id === productId);
        if (!isStillValid) {
          setProductId(valid[0].id);
        }
      } else {
        setProductId('');
      }
    }
  }, [selectedProductId, products, estoque]);

  // Sync reason default values when type changes
  useEffect(() => {
    setReason(COMMON_REASONS[type][0]);
    setCustomReason('');
  }, [type]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId) {
      alert('Selecione uma peça.');
      return;
    }

    if (quantity <= 0) {
      alert('A quantidade deve ser maior que zero.');
      return;
    }

    if (type === 'SAÍDA' && currentProduct && currentProduct.quantity < quantity) {
      alert(`Erro: Estoque insuficiente! A peça "${currentProduct.name}" possui apenas ${currentProduct.quantity} unidades, mas você tentou retirar ${quantity} unidades.`);
      return;
    }

    const isWyntechSaida = type === 'SAÍDA' && estoque === 'Wyntech';
    const isCaixaSaida = type === 'SAÍDA' && estoque === 'CAIXA';

    const finalTecnicoName = isWyntechSaida
      ? ((tecnico === 'custom_input' || showCustomTecnico) ? customTecnico.trim() : tecnico.trim())
      : undefined;

    if (isWyntechSaida) {
      if (!finalTecnicoName) {
        alert('Por favor, escolha ou preencha o campo Técnico.');
        return;
      }
      if (!chamado.trim()) {
        alert('Por favor, preencha o campo Chamado.');
        return;
      }
    }

    if (isCaixaSaida) {
      if (!unidadeDestino.trim()) {
        alert('Por favor, preencha o campo Unidade Destino.');
        return;
      }
      if (!usuario.trim()) {
        alert('Por favor, preencha o campo Usuário.');
        return;
      }
      if (!matricula.trim()) {
        alert('Por favor, preencha o campo Matrícula.');
        return;
      }
    }

    const finalReason = type === 'ENTRADA'
      ? `Entrada no estoque ${estoque}` + (serie.trim() ? ` - Série: ${serie.trim()}` : '')
      : isWyntechSaida
        ? `Saída Wyntech - Técnico: ${finalTecnicoName} - Chamado: ${chamado.trim()}`
        : isCaixaSaida
          ? `Saída CAIXA - Destino: ${unidadeDestino.trim()} - Usuário: ${usuario.trim()} (Matrícula: ${matricula.trim()})`
          : (reason === 'Outros' && customReason.trim() ? customReason.trim() : reason);

    onSave({
      productId,
      productName: currentProduct?.name || '',
      type,
      quantity,
      reason: finalReason,
      responsible: responsible.trim() || 'Administrador',
      estoque,
      serie: type === 'ENTRADA' ? (serie.trim() || undefined) : undefined,
      tecnico: finalTecnicoName,
      chamado: isWyntechSaida ? chamado.trim() : undefined,
      unidadeDestino: isCaixaSaida ? unidadeDestino.trim() : undefined,
      usuario: isCaixaSaida ? usuario.trim() : undefined,
      matricula: isCaixaSaida ? matricula.trim() : undefined
    });
  };

  const predictedStock = currentProduct 
    ? (type === 'ENTRADA' ? currentProduct.quantity + quantity : currentProduct.quantity - quantity)
    : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#111625]/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl transition-all border border-gray-100 max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between bg-gray-100 px-6 py-4 border-b border-gray-200">
          <div>
            <h3 className="text-lg font-bold text-gray-900">
              Registrar Movimentação
            </h3>
            <p className="text-xs text-gray-500">
              Lance entradas ou saídas de itens no estoque.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 hover:bg-gray-200 text-gray-400 hover:text-gray-600 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Movement Type Selector */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
              Tipo de Operação
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setType('ENTRADA')}
                className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-bold text-sm transition-all ${
                  type === 'ENTRADA'
                    ? 'border-[#10B981] bg-[#ECFDF5] text-[#10B981]'
                    : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                }`}
              >
                <ArrowUpCircle className="h-5 w-5" />
                Entrada
              </button>

              <button
                type="button"
                onClick={() => setType('SAÍDA')}
                className={`flex items-center justify-center gap-2 py-3 rounded-xl border-2 font-bold text-sm transition-all ${
                  type === 'SAÍDA'
                    ? 'border-[#EF4444] bg-[#FEF2F2] text-[#EF4444]'
                    : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                }`}
              >
                <ArrowDownCircle className="h-5 w-5" />
                Saída
              </button>
            </div>
          </div>

          {type === 'ENTRADA' ? (
            <>
              {/* 1. Campo automático de data */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Data (Automático)
                </label>
                <input
                  type="text"
                  disabled
                  value={new Date().toLocaleDateString('pt-BR') + ' ' + new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-gray-50 text-gray-500 outline-none transition cursor-not-allowed"
                />
              </div>

              {/* 2. Estoque (com lista CAIXA e Wyntech) */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Estoque *
                </label>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setIsEstoqueDropdownOpen(!isEstoqueDropdownOpen)}
                    className="w-full flex items-center justify-between rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white text-gray-900 font-medium outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition text-left"
                  >
                    <span>{estoque}</span>
                    <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isEstoqueDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isEstoqueDropdownOpen && (
                    <>
                      <div 
                        className="fixed inset-0 z-10" 
                        onClick={() => setIsEstoqueDropdownOpen(false)} 
                      />
                      <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-20 animate-in fade-in slide-in-from-top-2 duration-100">
                        <button
                          type="button"
                          onClick={() => {
                            setEstoque('CAIXA');
                            setIsEstoqueDropdownOpen(false);
                          }}
                          className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                            estoque === 'CAIXA' ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                          }`}
                        >
                          CAIXA
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEstoque('Wyntech');
                            setIsEstoqueDropdownOpen(false);
                          }}
                          className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                            estoque === 'Wyntech' ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                          }`}
                        >
                          Wyntech
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* 3. Peça */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Peça *
                </label>
                <select
                  required
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                >
                  <option value="" disabled>Selecione uma peça...</option>
                  {products.filter(p => (p.estoque || 'CAIXA') === estoque).map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (SKU: {p.sku}) - [{p.quantity} un]
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. Qtd */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                    Qtd *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                  />
                </div>

                <div className="flex flex-col justify-end">
                  {currentProduct ? (
                    <div className="bg-gray-50 rounded-xl p-2.5 border border-gray-100 text-xs">
                      <div className="flex justify-between text-gray-500">
                        <span>Atual:</span>
                        <span className="font-bold">{currentProduct.quantity} un</span>
                      </div>
                      <div className="flex justify-between mt-1 text-gray-700 font-semibold border-t border-gray-150 pt-1">
                        <span>Novo:</span>
                        <span className="font-extrabold text-emerald-600">
                          {predictedStock} un
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gray-50 rounded-xl p-2.5 border border-gray-100 text-xs text-gray-400 text-center py-4">
                      Selecione a peça
                    </div>
                  )}
                </div>
              </div>

              {/* 5. Série */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Série
                </label>
                <input
                  type="text"
                  placeholder="Ex: SN-92834729"
                  value={serie}
                  onChange={(e) => setSerie(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                />
              </div>

              {/* Responsável */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Responsável
                </label>
                <input
                  type="text"
                  value={responsible}
                  onChange={(e) => setResponsible(e.target.value)}
                  placeholder="Ex: Administrador"
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                />
              </div>
            </>
          ) : (
            <>
              {/* Data Automática */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Data (Automática)
                </label>
                <input
                  type="text"
                  disabled
                  value={new Date().toLocaleDateString('pt-BR')}
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-gray-50 text-gray-400 outline-none cursor-not-allowed select-none font-medium"
                />
              </div>

              {/* Estoque de Retirada */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Estoque (Retirada) *
                </label>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setIsEstoqueDropdownOpen(!isEstoqueDropdownOpen)}
                    className="w-full flex items-center justify-between rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white text-gray-900 font-medium outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition text-left"
                  >
                    <span>{estoque}</span>
                    <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isEstoqueDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isEstoqueDropdownOpen && (
                    <>
                      <div 
                        className="fixed inset-0 z-10" 
                        onClick={() => setIsEstoqueDropdownOpen(false)} 
                      />
                      <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-20 animate-in fade-in slide-in-from-top-2 duration-100">
                        <button
                          type="button"
                          onClick={() => {
                            setEstoque('CAIXA');
                            setIsEstoqueDropdownOpen(false);
                          }}
                          className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                            estoque === 'CAIXA' ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                          }`}
                        >
                          CAIXA
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEstoque('Wyntech');
                            setIsEstoqueDropdownOpen(false);
                          }}
                          className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                            estoque === 'Wyntech' ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                          }`}
                        >
                          Wyntech
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {estoque === 'Wyntech' ? (
                <>
                  {/* Técnico */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Técnico *
                    </label>
                    {technicians && technicians.length > 0 ? (
                      <>
                        <select
                          required
                          value={showCustomTecnico ? "custom_input" : tecnico}
                          onChange={(e) => {
                            if (e.target.value === "custom_input") {
                              setShowCustomTecnico(true);
                              setTecnico("custom_input");
                            } else {
                              setShowCustomTecnico(false);
                              setTecnico(e.target.value);
                            }
                          }}
                          className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                        >
                          <option value="" disabled>Selecione um técnico...</option>
                          {technicians.map((t) => (
                            <option key={t.id} value={t.nome}>
                              {t.nome} (MAT: {t.matricula})
                            </option>
                          ))}
                          <option value="custom_input">Outro técnico (digitar nome)...</option>
                        </select>

                        {showCustomTecnico && (
                          <input
                            type="text"
                            required
                            placeholder="Digite o nome do técnico"
                            value={customTecnico}
                            onChange={(e) => setCustomTecnico(e.target.value)}
                            className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition animate-in fade-in slide-in-from-top-1 duration-100"
                          />
                        )}
                      </>
                    ) : (
                      <input
                        type="text"
                        required
                        placeholder="Nome do técnico responsável"
                        value={tecnico}
                        onChange={(e) => setTecnico(e.target.value)}
                        className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                      />
                    )}
                  </div>

                  {/* Chamado */}
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Chamado *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: CH-2026-99"
                      value={chamado}
                      onChange={(e) => setChamado(e.target.value)}
                      className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                    />
                  </div>

                  {/* Peça (Custom dropdown with a list that descends on click) */}
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Peça *
                    </label>
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
                        className="w-full flex items-center justify-between rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white text-gray-900 font-medium outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition text-left"
                      >
                        <span>
                          {currentProduct 
                            ? `${currentProduct.name} (SKU: ${currentProduct.sku}) - [${currentProduct.quantity} un]` 
                            : 'Selecione uma peça...'}
                        </span>
                        <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isProductDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>
                      {isProductDropdownOpen && (
                        <>
                          <div 
                            className="fixed inset-0 z-10" 
                            onClick={() => setIsProductDropdownOpen(false)} 
                          />
                          <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg max-h-56 overflow-y-auto py-1 z-20 animate-in fade-in slide-in-from-top-2 duration-100">
                            {products.filter(p => (p.estoque || 'CAIXA') === 'Wyntech').length === 0 ? (
                              <div className="px-4 py-3 text-xs text-gray-400 text-center">
                                Nenhuma peça cadastrada no estoque Wyntech.
                              </div>
                            ) : (
                              products.filter(p => (p.estoque || 'CAIXA') === 'Wyntech').map((p) => (
                                <button
                                  key={p.id}
                                  type="button"
                                  onClick={() => {
                                    setProductId(p.id);
                                    setIsProductDropdownOpen(false);
                                  }}
                                  className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors flex justify-between items-center ${
                                    productId === p.id ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                                  }`}
                                >
                                  <div>
                                    <p className="font-semibold text-xs text-gray-900">{p.name}</p>
                                    <p className="text-[10px] text-gray-400 font-mono mt-0.5">SKU: {p.sku}</p>
                                  </div>
                                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                                    p.quantity === 0 
                                      ? 'bg-red-50 text-red-500' 
                                      : p.quantity <= p.minQuantity 
                                        ? 'bg-amber-50 text-amber-600' 
                                        : 'bg-emerald-50 text-emerald-600'
                                  }`}>
                                    {p.quantity} un
                                  </span>
                                </button>
                              ))
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* Unidade Destino */}
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Unidade Destino *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Unidade Centro"
                      value={unidadeDestino}
                      onChange={(e) => setUnidadeDestino(e.target.value)}
                      className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-[#8A6E45] focus:ring-1 focus:ring-[#8A6E45]/30 transition"
                    />
                  </div>

                  {/* Usuário */}
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Usuário *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: João Silva"
                      value={usuario}
                      onChange={(e) => setUsuario(e.target.value)}
                      className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-[#8A6E45] focus:ring-1 focus:ring-[#8A6E45]/30 transition"
                    />
                  </div>

                  {/* Matrícula */}
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Matrícula *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: MAT-12345"
                      value={matricula}
                      onChange={(e) => setMatricula(e.target.value)}
                      className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-[#8A6E45] focus:ring-1 focus:ring-[#8A6E45]/30 transition"
                    />
                  </div>

                  {/* Peça (Custom dropdown with a list that descends on click) */}
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                      Peça *
                    </label>
                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setIsProductDropdownOpen(!isProductDropdownOpen)}
                        className="w-full flex items-center justify-between rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white text-[#111625] font-medium outline-none focus:border-[#8A6E45] focus:ring-1 focus:ring-[#8A6E45]/30 transition text-left"
                      >
                        <span>
                          {currentProduct 
                            ? `${currentProduct.name} (SKU: ${currentProduct.sku}) - [${currentProduct.quantity} un]` 
                            : 'Selecione uma peça...'}
                        </span>
                        <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isProductDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>
                      {isProductDropdownOpen && (
                        <>
                          <div 
                            className="fixed inset-0 z-10" 
                            onClick={() => setIsProductDropdownOpen(false)} 
                          />
                          <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg max-h-56 overflow-y-auto py-1 z-20 animate-in fade-in slide-in-from-top-2 duration-100">
                            {products.filter(p => (p.estoque || 'CAIXA') === 'CAIXA').length === 0 ? (
                              <div className="px-4 py-3 text-xs text-gray-400 text-center">
                                Nenhuma peça cadastrada no estoque CAIXA.
                              </div>
                            ) : (
                              products.filter(p => (p.estoque || 'CAIXA') === 'CAIXA').map((p) => (
                                <button
                                  key={p.id}
                                  type="button"
                                  onClick={() => {
                                    setProductId(p.id);
                                    setIsProductDropdownOpen(false);
                                  }}
                                  className={`w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors flex justify-between items-center ${
                                    productId === p.id ? 'font-bold text-[#8A6E45] bg-[#FAF4E8]/50' : 'text-gray-700'
                                  }`}
                                >
                                  <div>
                                    <p className="font-semibold text-xs text-gray-900">{p.name}</p>
                                    <p className="text-[10px] text-gray-400 font-mono mt-0.5">SKU: {p.sku}</p>
                                  </div>
                                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                                    p.quantity === 0 
                                      ? 'bg-red-50 text-red-500' 
                                      : p.quantity <= p.minQuantity 
                                        ? 'bg-amber-50 text-amber-600' 
                                        : 'bg-emerald-50 text-emerald-600'
                                  }`}>
                                    {p.quantity} un
                                  </span>
                                </button>
                              ))
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* Quantity & Stock Indicator */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                    Quantidade *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                  />
                </div>

                <div className="flex flex-col justify-end">
                  {currentProduct ? (
                    <div className="bg-gray-50 rounded-xl p-2.5 border border-gray-100 text-xs">
                      <div className="flex justify-between text-gray-500">
                        <span>Estoque Atual:</span>
                        <span className="font-bold">{currentProduct.quantity}</span>
                      </div>
                      <div className="flex justify-between mt-1 text-gray-700 font-semibold border-t border-gray-150 pt-1">
                        <span>Novo Saldo:</span>
                        <span className={`font-extrabold ${predictedStock < currentProduct.minQuantity ? 'text-red-500' : 'text-emerald-600'}`}>
                          {predictedStock} un
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gray-50 rounded-xl p-2.5 border border-gray-100 text-xs text-gray-400 text-center py-4">
                      Selecione uma peça
                    </div>
                  )}
                </div>
              </div>

              {/* Responsible Person */}
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                  Responsável pelo Lançamento
                </label>
                <input
                  type="text"
                  value={responsible}
                  onChange={(e) => setResponsible(e.target.value)}
                  placeholder="Ex: Administrador"
                  className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
                />
              </div>
            </>
          )}

          {/* Submit Action */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-gray-200 py-3 text-sm font-semibold text-gray-600 hover:bg-gray-50 active:bg-gray-100 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 rounded-xl bg-gray-600 py-3 text-sm font-semibold text-white hover:bg-gray-700 active:scale-95 transition-all shadow-md"
            >
              Registrar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
