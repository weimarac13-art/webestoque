import React, { useState, useEffect } from 'react';
import { X, Phone, User, MessageSquare } from 'lucide-react';
import { Movement, Technician } from '../types';

interface WhatsAppModalProps {
  movement: Movement;
  technicians: Technician[];
  onClose: () => void;
}

export default function WhatsAppModal({ movement, technicians, onClose }: WhatsAppModalProps) {
  const [selectedPhoneType, setSelectedPhoneType] = useState<'corporativo' | 'pessoal' | 'manual'>('corporativo');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [message, setMessage] = useState('');

  // Find corresponding technician
  const technician = technicians.find(t => t.nome.trim().toLowerCase() === movement.tecnico?.trim().toLowerCase());

  // Format phone helper
  const formatPhone = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length <= 10) {
      return cleaned.replace(/^(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    }
    return cleaned.substring(0, 11).replace(/^(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  };

  const cleanPhoneNum = (num: string) => {
    const cleaned = num.replace(/\D/g, '');
    if (cleaned.length === 10 || cleaned.length === 11) {
      return '55' + cleaned; // Prepend Brazil country code
    }
    return cleaned;
  };

  // Initialize phone number and message
  useEffect(() => {
    if (technician) {
      if (technician.celCorporativo) {
        setPhoneNumber(formatPhone(technician.celCorporativo));
        setSelectedPhoneType('corporativo');
      } else if (technician.celPessoal) {
        setPhoneNumber(formatPhone(technician.celPessoal));
        setSelectedPhoneType('pessoal');
      } else {
        setPhoneNumber('');
        setSelectedPhoneType('manual');
      }
    } else {
      setPhoneNumber('');
      setSelectedPhoneType('manual');
    }

    const formattedDate = new Date(movement.date).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    const defaultMsg = `Olá, *${movement.tecnico}*! 🛠️\n\n` +
      `Foi registrada a seguinte retirada de peça do estoque *Wyntech*:\n\n` +
      `📦 *Peça:* ${movement.productName}\n` +
      `🔢 *Quantidade:* ${movement.quantity} un\n` +
      `📝 *Chamado:* ${movement.chamado || 'N/A'}\n` +
      `🕒 *Data/Hora:* ${formattedDate}\n` +
      `👤 *Responsável:* ${movement.responsible}\n\n` +
      `Por favor, verifique se as informações estão corretas!`;

    setMessage(defaultMsg);
  }, [movement, technician]);

  // Handle phone selection changes
  const handlePhoneTypeChange = (type: 'corporativo' | 'pessoal' | 'manual') => {
    setSelectedPhoneType(type);
    if (technician) {
      if (type === 'corporativo') {
        setPhoneNumber(formatPhone(technician.celCorporativo || ''));
      } else if (type === 'pessoal') {
        setPhoneNumber(formatPhone(technician.celPessoal || ''));
      } else {
        setPhoneNumber('');
      }
    }
  };

  // Construct the WhatsApp Link
  const cleanedNum = cleanPhoneNum(phoneNumber);
  const whatsappUrl = `https://api.whatsapp.com/send?phone=${cleanedNum}&text=${encodeURIComponent(message)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl border border-gray-100 flex flex-col animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header with WhatsApp branding colors */}
        <div className="flex items-center justify-between bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-5 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <svg className="h-6 w-6 fill-current text-white" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.458 5.705 1.459h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-black tracking-tight">Enviar via WhatsApp</h3>
              <p className="text-xs text-emerald-100 font-medium">Notifique o técnico sobre a retirada.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 hover:bg-white/10 text-emerald-100 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          
          {/* Technician overview */}
          <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 flex gap-3 items-center">
            <div className="p-2.5 bg-white rounded-xl border border-gray-150 text-gray-400 shrink-0">
              <User className="h-5 w-5" />
            </div>
            <div className="text-left min-w-0">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">TÉCNICO DESTINATÁRIO</p>
              <h4 className="text-sm font-black text-gray-900 truncate mt-0.5">
                {movement.tecnico}
              </h4>
              {technician && (
                <span className="text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded-full mt-1 inline-block">
                  MAT: {technician.matricula}
                </span>
              )}
            </div>
          </div>

          {/* Phone selection */}
          {technician && (technician.celCorporativo || technician.celPessoal) ? (
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                Selecione o Contato
              </label>
              <div className="grid grid-cols-2 gap-2">
                {technician.celCorporativo && (
                  <button
                    type="button"
                    onClick={() => handlePhoneTypeChange('corporativo')}
                    className={`px-3 py-2 text-xs font-bold rounded-xl border text-center transition-all ${
                      selectedPhoneType === 'corporativo'
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                        : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    💼 Corporativo
                  </button>
                )}
                {technician.celPessoal && (
                  <button
                    type="button"
                    onClick={() => handlePhoneTypeChange('pessoal')}
                    className={`px-3 py-2 text-xs font-bold rounded-xl border text-center transition-all ${
                      selectedPhoneType === 'pessoal'
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                        : 'border-gray-200 text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    👤 Pessoal
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-amber-50 border border-amber-150 rounded-2xl p-3 text-xs text-amber-800 text-left">
              ⚠️ Este técnico não possui celulares cadastrados em sua ficha. Digite o número desejado abaixo.
            </div>
          )}

          {/* Phone Input */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
              WhatsApp do Técnico *
            </label>
            <div className="relative">
              <Phone className="absolute left-3.5 top-3 h-4 w-4 text-gray-400" />
              <input
                type="text"
                required
                placeholder="(00) 00000-0000"
                value={phoneNumber}
                onChange={(e) => {
                  setPhoneNumber(formatPhone(e.target.value));
                  if (selectedPhoneType !== 'manual') {
                    setSelectedPhoneType('manual');
                  }
                }}
                className="w-full rounded-xl border border-gray-200 pl-10 pr-4 py-2.5 text-sm outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/30 transition bg-white"
              />
            </div>
          </div>

          {/* Message preview and editor */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5 flex justify-between">
              <span>Mensagem para Envio</span>
              <span className="text-[10px] text-gray-400 lowercase font-normal">Edição habilitada</span>
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={6}
              className="w-full rounded-xl border border-gray-200 px-3.5 py-2.5 text-xs outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/30 transition bg-gray-50/50 font-sans resize-none"
            />
          </div>

          {/* Dialog Action Buttons */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-gray-200 py-3 text-sm font-bold text-gray-500 hover:bg-gray-50 active:scale-95 transition-all text-center"
            >
              Agora Não
            </button>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={onClose}
              className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 py-3 text-sm font-extrabold text-white active:scale-95 transition-all shadow-md text-center shadow-emerald-600/10"
            >
              <svg className="h-4 w-4 fill-current text-white" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.746.953 3.71 1.458 5.705 1.459h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              Enviar WhatsApp
            </a>
          </div>

        </div>

      </div>
    </div>
  );
}
