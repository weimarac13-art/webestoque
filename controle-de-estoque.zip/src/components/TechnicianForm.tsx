import React, { useState } from 'react';
import { X, UserPlus } from 'lucide-react';
import { Technician } from '../types';

interface TechnicianFormProps {
  initialData?: Technician;
  onSave: (technician: Omit<Technician, 'id' | 'createdAt'>) => void;
  onClose: () => void;
}

export default function TechnicianForm({ initialData, onSave, onClose }: TechnicianFormProps) {
  const [matricula, setMatricula] = useState(initialData?.matricula || '');
  const [nome, setNome] = useState(initialData?.nome || '');
  const [cpf, setCpf] = useState(initialData?.cpf || '');
  const [rg, setRg] = useState(initialData?.rg || '');
  const [dataNascimento, setDataNascimento] = useState(initialData?.dataNascimento || '');
  const [celPessoal, setCelPessoal] = useState(initialData?.celPessoal || '');
  const [celCorporativo, setCelCorporativo] = useState(initialData?.celCorporativo || '');

  // Format phone function
  const formatPhone = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length <= 10) {
      return cleaned.replace(/^(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
    }
    return cleaned.substring(0, 11).replace(/^(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  };

  // Format CPF function
  const formatCPF = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    return cleaned
      .substring(0, 11)
      .replace(/^(\d{3})(\d{3})(\d{3})(\d{1,2})/, '$1.$2.$3-$4');
  };

  // Format Date function (DD/MM/AAAA)
  const formatDate = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.length <= 2) {
      return cleaned;
    }
    if (cleaned.length <= 4) {
      return `${cleaned.slice(0, 2)}/${cleaned.slice(2)}`;
    }
    return `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}/${cleaned.slice(4, 8)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<string>>) => {
    setter(formatPhone(e.target.value));
  };

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCpf(formatCPF(e.target.value));
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDataNascimento(formatDate(e.target.value));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!matricula.trim() || !nome.trim()) {
      alert('Por favor, preencha os campos obrigatórios (Matrícula e Nome).');
      return;
    }

    onSave({
      matricula: matricula.trim(),
      nome: nome.trim(),
      cpf: cpf.trim(),
      rg: rg.trim(),
      dataNascimento,
      celPessoal: celPessoal.trim(),
      celCorporativo: celCorporativo.trim(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#111625]/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl transition-all border border-gray-100 max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-100 to-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gray-100 rounded-xl">
              <UserPlus className="h-5 w-5 text-gray-600" />
            </div>
            <div>
              <h3 className="font-black text-gray-900 text-lg">{initialData ? 'Editar Técnico' : 'Cadastrar Técnico'}</h3>
              <p className="text-xs text-gray-500">{initialData ? 'Atualize as informações do profissional' : 'Adicione um novo profissional ao sistema'}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 text-left">
          {/* Matrícula */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
              Matrícula *
            </label>
            <input
              type="text"
              required
              placeholder="Ex: MAT-1234"
              value={matricula}
              onChange={(e) => setMatricula(e.target.value)}
              className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
            />
          </div>

          {/* Nome */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
              Nome Completo *
            </label>
            <input
              type="text"
              required
              placeholder="Nome do técnico"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* CPF */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                CPF
              </label>
              <input
                type="text"
                placeholder="000.000.000-00"
                value={cpf}
                onChange={handleCPFChange}
                className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
              />
            </div>

            {/* RG */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                RG
              </label>
              <input
                type="text"
                placeholder="Ex: 12.345.678-9"
                value={rg}
                onChange={(e) => setRg(e.target.value)}
                className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
              />
            </div>
          </div>

          {/* Data de Nascimento */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
              Data de Nascimento
            </label>
            <input
              type="text"
              placeholder="Ex: DD/MM/AAAA"
              value={dataNascimento}
              onChange={handleDateChange}
              maxLength={10}
              className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition bg-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Celular Pessoal */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                Celular Pessoal
              </label>
              <input
                type="text"
                placeholder="(00) 00000-0000"
                value={celPessoal}
                onChange={(e) => handlePhoneChange(e, setCelPessoal)}
                className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
              />
            </div>

            {/* Celular Corporativo */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                Celular Corporativo
              </label>
              <input
                type="text"
                placeholder="(00) 00000-0000"
                value={celCorporativo}
                onChange={(e) => handlePhoneChange(e, setCelCorporativo)}
                className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-gray-200 px-4 py-3 text-sm font-semibold text-gray-900 hover:bg-gray-50 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 rounded-xl bg-gray-600 px-4 py-3 text-sm font-semibold text-white hover:bg-gray-700 active:scale-95 transition"
            >
              {initialData ? 'Salvar Alterações' : 'Salvar Técnico'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
