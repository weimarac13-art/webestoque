import React from 'react';
import { Menu, Search, Bell, Edit3, Calendar } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
  onSearchClick: () => void;
  onNotificationsClick: () => void;
  onQuickAddClick: () => void;
  onCalendarClick: () => void;
  notificationCount: number;
}

export default function Header({
  onMenuClick,
  onSearchClick,
  onNotificationsClick,
  onQuickAddClick,
  onCalendarClick,
  notificationCount
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between bg-gray-100 px-4 border-b border-gray-200 shadow-sm">
      {/* Left Menu Button */}
      <button
        id="btn-sidebar-toggle"
        onClick={onMenuClick}
        className="flex h-10 w-10 items-center justify-center rounded-lg text-gray-700 transition hover:bg-gray-200 active:scale-95"
      >
        <Menu className="h-6 w-6" />
      </button>

      {/* Center Logo Area */}
      <div className="flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gray-800 border border-gray-400">
          <span className="font-mono text-sm font-bold tracking-tight text-gray-400">SE</span>
        </div>
        <span className="font-sans text-xl font-extrabold tracking-tight text-gray-900">
          SISEST
        </span>
      </div>

      {/* Right Utility Buttons */}
      <div className="flex items-center gap-1.5 md:gap-3">
        <button
          id="btn-header-search"
          onClick={onSearchClick}
          className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-700 transition hover:bg-gray-200 active:scale-95"
        >
          <Search className="h-5 w-5" />
        </button>

        <button
          id="btn-header-notifications"
          onClick={onNotificationsClick}
          className="relative flex h-9 w-9 items-center justify-center rounded-lg text-gray-700 transition hover:bg-gray-200 active:scale-95"
        >
          <Bell className="h-5 w-5" />
          {notificationCount > 0 && (
            <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ring-2 ring-gray-100">
              {notificationCount}
            </span>
          )}
        </button>

        <button
          id="btn-header-quick-add"
          onClick={onQuickAddClick}
          className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-700 transition hover:bg-gray-200 active:scale-95"
        >
          <Edit3 className="h-5 w-5" />
        </button>

        <button
          id="btn-header-calendar"
          onClick={onCalendarClick}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-200 text-gray-700 border border-gray-300 transition hover:bg-gray-300 active:scale-95"
        >
          <Calendar className="h-5 w-5" />
        </button>
      </div>
    </header>
  );
}
