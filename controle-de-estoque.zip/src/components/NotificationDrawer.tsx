import React from 'react';
import { X, AlertTriangle, Info, CheckCircle2, Trash2 } from 'lucide-react';
import { Notification } from '../types';

interface NotificationDrawerProps {
  notifications: Notification[];
  onClose: () => void;
  onMarkAsRead: (id: string) => void;
  onClearAll: () => void;
}

export default function NotificationDrawer({
  notifications,
  onClose,
  onMarkAsRead,
  onClearAll
}: NotificationDrawerProps) {
  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#111625]/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />

      {/* Drawer Body */}
      <div className="relative w-full max-w-sm h-full bg-white shadow-2xl flex flex-col border-l border-gray-100 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="flex items-center justify-between bg-gray-100 px-5 py-4 border-b border-gray-200">
          <div>
            <h3 className="text-lg font-bold text-gray-900">Notificações</h3>
            <p className="text-xs text-gray-500">
              Alertas de estoque e movimentações importantes.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 hover:bg-gray-200 text-gray-400 hover:text-gray-600 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Action controls */}
        {notifications.length > 0 && (
          <div className="flex justify-between items-center px-5 py-2.5 bg-gray-50 border-b border-gray-100 text-xs">
            <span className="text-gray-500 font-medium">
              {notifications.filter(n => !n.read).length} não lidas
            </span>
            <button
              id="btn-clear-all-notifications"
              onClick={onClearAll}
              className="flex items-center gap-1 font-semibold text-red-500 hover:text-red-700 transition"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Limpar tudo
            </button>
          </div>
        )}

        {/* List of notifications */}
        <div className="flex-1 overflow-y-auto divide-y divide-gray-100">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center text-gray-400">
              <CheckCircle2 className="h-12 w-12 text-emerald-400 mb-2 stroke-[1.5]" />
              <p className="font-semibold text-gray-600 text-sm">Sem notificações!</p>
              <p className="text-xs mt-1">Seu estoque está bem gerenciado e sem pendências críticas no momento.</p>
            </div>
          ) : (
            notifications.map((notif) => {
              const isUnread = !notif.read;
              return (
                <div
                  key={notif.id}
                  onClick={() => onMarkAsRead(notif.id)}
                  className={`p-4 transition cursor-pointer flex gap-3 text-left ${
                    isUnread ? 'bg-amber-50/40 hover:bg-amber-50' : 'hover:bg-gray-50'
                  }`}
                >
                  {/* Icon Indicator */}
                  <div className="mt-0.5 shrink-0">
                    {notif.type === 'ALERT' ? (
                      <div className="p-1.5 rounded-lg bg-red-100 text-red-500">
                        <AlertTriangle className="h-4 w-4" />
                      </div>
                    ) : notif.type === 'SUCCESS' ? (
                      <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-500">
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                    ) : (
                      <div className="p-1.5 rounded-lg bg-blue-100 text-blue-500">
                        <Info className="h-4 w-4" />
                      </div>
                    )}
                  </div>

                  {/* Message details */}
                  <div className="flex-1">
                    <div className="flex justify-between items-start gap-1">
                      <p className={`text-xs font-bold text-[#111625] ${isUnread ? 'font-extrabold' : ''}`}>
                        {notif.title}
                      </p>
                      {isUnread && (
                        <span className="h-2 w-2 rounded-full bg-amber-500 shrink-0 mt-1" />
                      )}
                    </div>
                    <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">
                      {notif.message}
                    </p>
                    <span className="text-[10px] text-gray-400 mt-2 block font-mono">
                      {new Date(notif.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
