import React from 'react';
import { Home, Package, ArrowUpDown, AlertTriangle, DollarSign } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  lowStockCount: number;
}

export default function BottomNav({ activeTab, onChangeTab, lowStockCount }: BottomNavProps) {
  const tabs = [
    {
      id: 'inicio' as ActiveTab,
      label: 'Início',
      icon: Home,
    },
    {
      id: 'produtos' as ActiveTab,
      label: 'Produtos',
      icon: Package,
    },
    {
      id: 'movimentacoes' as ActiveTab,
      label: 'Movimentações',
      icon: ArrowUpDown,
    },
    {
      id: 'alertas' as ActiveTab,
      label: 'Alertas',
      icon: AlertTriangle,
      badge: lowStockCount > 0 ? lowStockCount : undefined,
    },
    {
      id: 'financeiro' as ActiveTab,
      label: 'Financeiro',
      icon: DollarSign,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 flex h-16 w-full items-center justify-around bg-gray-100 border-t border-gray-200 shadow-lg px-2 pb-safe">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            id={`btn-nav-${tab.id}`}
            onClick={() => onChangeTab(tab.id)}
            className="relative flex flex-col items-center justify-center w-16 h-full transition-all active:scale-90"
          >
            <div
              className={`flex flex-col items-center justify-center rounded-xl p-1 transition-all ${
                isActive
                  ? 'text-gray-700 font-semibold'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="relative">
                <Icon className={`h-6 w-6 transition-transform ${isActive ? 'scale-110 stroke-[2.5px]' : 'stroke-[1.8px]'}`} />
                {tab.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-[11px] mt-0.5 transition-all ${isActive ? 'font-bold' : 'font-medium'}`}>
                {tab.label}
              </span>
            </div>
            
            {/* Active Accent Dot/Indicator */}
            {isActive && (
              <span className="absolute bottom-1 h-1 w-1 rounded-full bg-gray-700" />
            )}
          </button>
        );
      })}
    </nav>
  );
}
