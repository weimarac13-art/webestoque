import React from 'react';
import { ChevronRight, LucideIcon } from 'lucide-react';

interface MetricCardProps {
  id: string;
  title: string;
  value: string | number;
  icon: LucideIcon;
  iconBgColor: string;
  iconColor: string;
  onClick?: () => void;
}

export default function MetricCard({
  id,
  title,
  value,
  icon: Icon,
  iconBgColor,
  iconColor,
  onClick
}: MetricCardProps) {
  return (
    <button
      id={`metric-card-${id}`}
      onClick={onClick}
      className="flex w-full items-center justify-between rounded-3xl border border-gray-100 bg-white p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)] active:scale-[0.99] text-left"
    >
      <div className="flex items-center gap-4">
        {/* Rounded Icon Container */}
        <div className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl ${iconBgColor}`}>
          <Icon className={`h-8 w-8 ${iconColor}`} />
        </div>

        {/* Info Area */}
        <div className="flex flex-col">
          <span className="text-lg sm:text-xl font-extrabold text-gray-900 tracking-tight">
            {title}
          </span>
          {value && (
            <span className="mt-1 text-3xl sm:text-4xl font-extrabold tracking-tight text-gray-900">
              {value}
            </span>
          )}
        </div>
      </div>

      {/* Right Arrow */}
      <div className="text-gray-300 pr-1">
        <ChevronRight className="h-6 w-6 stroke-[2.5px] text-gray-400" />
      </div>
    </button>
  );
}
