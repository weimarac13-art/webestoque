import React, { useState, useEffect } from 'react';
import { X, Sparkles, ChevronDown, CheckCircle2 } from 'lucide-react';
import { Product } from '../types';
import { CATEGORIES } from '../data';

interface ProductFormProps {
  product?: Product | null; // If editing
  onSave: (product: Omit<Product, 'createdAt'> & { id?: string }, keepOpen?: boolean) => void;
  onClose: () => void;
}

export default function ProductForm({ product, onSave, onClose }: ProductFormProps) {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [quantity, setQuantity] = useState(0);
  const [minQuantity, setMinQuantity] = useState(5);
  const [costPrice, setCostPrice] = useState(0);
  const [salePrice, setSalePrice] = useState(0);
  const [supplier, setSupplier] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [estoque, setEstoque] = useState<'CAIXA' | 'Wyntech'>('CAIXA');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [showConfirmAnother, setShowConfirmAnother] = useState(false);

  // Auto generate SKU for fun
  const handleGenerateSKU = () => {
    const catCode = category.substring(0, 2).toUpperCase();
    const randomNum = Math.floor(100 + Math.random() * 900);
    const nameCode = name ? name.substring(0, 3).toUpperCase() : 'PRD';
    setSku(`${catCode}-${nameCode}-${randomNum}`);
  };

  useEffect(() => {
    if (product) {
      setName(product.name);
      setSku(product.sku);
      setCategory(product.category);
      setQuantity(product.quantity);
      setMinQuantity(product.minQuantity);
      setCostPrice(product.costPrice);
      setSalePrice(product.salePrice);
      setSupplier(product.supplier);
      setLocation(product.location);
      setDescription(product.description);
      setEstoque(product.estoque || 'CAIXA');
    } else {
      // Clear fields for new product
      setName('');
      setSku('');
      setCategory(CATEGORIES[0]);
      setQuantity(0);
      setMinQuantity(5);
      setCostPrice(0);
      setSalePrice(0);
      setSupplier('');
      setLocation('');
      setDescription('');
      setEstoque('CAIXA');
    }
  }, [product]);

  const handleRegisterAnother = () => {
    setName('');
    setSku('');
    setCategory(CATEGORIES[0]);
    setQuantity(0);
    setMinQuantity(5);
    setCostPrice(0);
    setSalePrice(0);
    setSupplier('');
    setLocation('');
    setDescription('');
    setEstoque('CAIXA');
    setShowConfirmAnother(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Por favor, preencha o campo Peça.');
      return;
    }
    
    // Auto-generate SKU and default category in background to prevent system breaking
    const finalSku = product?.sku || `PC-${name.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;
    const finalCategory = product?.category || CATEGORIES[0] || 'Geral';
    
    const dataToSave = {
      id: product?.id,
      name,
      sku: finalSku,
      category: finalCategory,
      quantity: Number(quantity),
      minQuantity: product?.minQuantity ?? 0,
      costPrice: product?.costPrice ?? 0,
      salePrice: product?.salePrice ?? 0,
      supplier: product?.supplier ?? '',
      location: product?.location ?? '',
      description: product?.description ?? '',
      estoque,
    };

    if (product) {
      onSave(dataToSave);
    } else {
      onSave(dataToSave, true); // Keep open in App.tsx
      setShowConfirmAnother(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#111625]/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl transition-all border border-gray-100 max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between bg-gray-100 px-6 py-4 border-b border-gray-200">
          <div>
            <h3 className="text-lg font-bold text-gray-900">
              {product ? 'Editar Peça' : 'Cadastrar Peça'}
            </h3>
            <p className="text-xs text-gray-500">
              Preencha os campos abaixo para atualizar o estoque.
            </p>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 hover:bg-gray-200 text-gray-400 hover:text-gray-600 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Product Name */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
              Peça *
            </label>
            <input
              type="text"
              required
              placeholder="Ex: Teclado Mecânico Gamer"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition"
            />
          </div>

          {/* Stock Quantities & Location */}
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
              Estoque *
            </label>
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="w-full flex items-center justify-between rounded-xl border border-gray-200 px-4 py-2.5 text-sm bg-white text-gray-900 font-medium outline-none focus:border-gray-500 focus:ring-1 focus:ring-gray-500/30 transition text-left"
              >
                <span>{estoque}</span>
                <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
              </button>
              {isDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setIsDropdownOpen(false)} 
                  />
                  <div className="absolute left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-lg py-1 z-20 animate-in fade-in slide-in-from-top-2 duration-100">
                    <button
                      type="button"
                      onClick={() => {
                        setEstoque('CAIXA');
                        setIsDropdownOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                        estoque === 'CAIXA' ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                      }`}
                    >
                      CAIXA
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEstoque('Wyntech');
                        setIsDropdownOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                        estoque === 'Wyntech' ? 'font-bold text-gray-700 bg-gray-200/50' : 'text-gray-700'
                      }`}
                    >
                      Wyntech
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Submit Button */}
          {/* Submit Button */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-xl border border-gray-200 py-3 text-sm font-semibold text-gray-600 hover:bg-gray-50 active:bg-gray-100 transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 rounded-xl bg-gray-600 py-3 text-sm font-semibold text-white hover:bg-gray-700 active:scale-95 transition-all shadow-md"
            >
              {product ? 'Salvar Alterações' : 'Cadastrar'}
            </button>
          </div>
        </form>

        {showConfirmAnother && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-gray-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-gray-100 shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-200">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-black text-gray-900">Peça Cadastrada!</h3>
                <p className="text-xs text-gray-500 mt-1">
                  Deseja cadastrar outra peça?
                </p>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-gray-500 hover:bg-gray-50 active:scale-95 transition"
                >
                  Não, fechar
                </button>
                <button
                  type="button"
                  onClick={handleRegisterAnother}
                  className="flex-1 py-2.5 rounded-xl bg-gray-600 text-xs font-bold text-white hover:bg-gray-700 active:scale-95 transition"
                >
                  Sim, outra peça
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
