export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  minQuantity: number;
  costPrice: number;
  salePrice: number;
  supplier: string;
  location: string;
  description: string;
  createdAt: string;
  estoque?: 'CAIXA' | 'Wyntech';
}

export interface Movement {
  id: string;
  productId: string;
  productName: string;
  type: 'ENTRADA' | 'SAÍDA';
  quantity: number;
  date: string;
  reason: string;
  responsible: string;
  estoque?: 'CAIXA' | 'Wyntech';
  serie?: string;
  tecnico?: string;
  chamado?: string;
  unidadeDestino?: string;
  usuario?: string;
  matricula?: string;
}

export interface Notification {
  id: string;
  type: 'ALERT' | 'INFO' | 'SUCCESS';
  title: string;
  message: string;
  date: string;
  read: boolean;
}

export interface Technician {
  id: string;
  matricula: string;
  nome: string;
  cpf: string;
  rg: string;
  dataNascimento: string;
  celPessoal: string;
  celCorporativo: string;
  createdAt: string;
}

export type ActiveTab = 'inicio' | 'produtos' | 'movimentacoes' | 'alertas' | 'financeiro' | 'tecnicos' | 'agencia';
